import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import '../../../core/config/app_config.dart';

class AuthRepository {
  final _storage = const FlutterSecureStorage();

  // Base URL from .env
  final String _baseUrl = AppConfig.baseUrl;

  Future<Map<String, dynamic>> login(String email, String password) async {
    final url = Uri.parse("$_baseUrl/auth/login");

    final response = await http.post(
      url,
      headers: {
        "Content-Type": "application/json",
      },
      body: jsonEncode({
        "email": email,
        "password": password,
      }),
    );

    final responseData = jsonDecode(response.body);

    if (response.statusCode == 200) {
      final tokens = responseData["data"];

      await _storage.write(
        key: "accessToken",
        value: tokens["accessToken"],
      );

      await _storage.write(
        key: "refreshToken",
        value: tokens["refreshToken"],
      );

      return responseData;
    }

    throw Exception(responseData["message"] ?? "Login failed");
  }

  Future<void> logout() async {
    await _storage.deleteAll();
  }
}