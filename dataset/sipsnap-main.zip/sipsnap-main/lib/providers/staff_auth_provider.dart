import 'package:flutter/foundation.dart';

class StaffAuthProvider with ChangeNotifier {
  String? _staffId;
  Map<String, dynamic>? _staffDetails;

  String? get staffId => _staffId;
  Map<String, dynamic>? get staffDetails => _staffDetails;

  void setStaffData(Map<String, dynamic> data) {
    _staffDetails = data;
    _staffId = data['id']?.toString() ?? data['_id']?.toString();

    debugPrint("Parsed Staff ID successfully: $_staffId");
    notifyListeners();
  }

  void logoutStaff() {
    _staffId = null;
    _staffDetails = null;
    notifyListeners();
  }
}