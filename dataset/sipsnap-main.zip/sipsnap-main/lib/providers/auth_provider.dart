import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../models/user_model.dart';
import '../core/config/app_config.dart';

class AuthProvider with ChangeNotifier {
  String? _accessToken;
  String? _refreshToken;
  UserModel? _user;

  String? get accessToken => _accessToken;
  String? get refreshToken => _refreshToken;
  UserModel? get user => _user;
  bool get isAuthenticated => _accessToken != null && _accessToken!.isNotEmpty;

  // 1. Triggered when your login API succeeds
  Future<void> handleLoginResponse(Map<String, dynamic> loginJson) async {
    final data = loginJson['data'];
    _accessToken = data['accessToken'];
    _refreshToken = data['refreshToken'];

    notifyListeners(); // Save token state globally

    // 2. Automatically fetch /me route using the new access token
    await fetchUserProfile();
  }

  // 3. Fetch user details from /me endpoint
  Future<void> fetchUserProfile() async {
    if (_accessToken == null) return;

    try {
      final response = await http.get(
        Uri.parse('${AppConfig.baseUrl}/auth/me'), // Replace with your actual /me URL
        headers: {
          'Authorization': 'Bearer $_accessToken',
          'Content-Type': 'application/json',
        },
      );

      if (response.statusCode == 200) {
        final decoded = jsonDecode(response.body);
        final userData = decoded['data']; // Matches your /me response structure

        _user = UserModel.fromJson(userData);
        notifyListeners(); // Triggers UI update globally for Consumer widgets
      } else {
        logout();
      }
    } catch (e) {
      debugPrint("Error fetching profile: $e");
    }
  }

  // 4. Clear state on logout
  void logout() {
    _accessToken = null;
    _refreshToken = null;
    _user = null;
    notifyListeners();
  }
}