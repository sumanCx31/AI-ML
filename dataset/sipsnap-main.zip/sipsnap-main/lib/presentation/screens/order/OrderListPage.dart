import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../../../core/config/app_config.dart';
import '../../../providers/auth_provider.dart';
import '../../../providers/staff_auth_provider.dart';
import '../../widgets/sipsnap_loading_logo.dar.dart'; // Professional animated logo import
import 'order_items_list.dart';
import './orderFromQr.dart'; // Make sure this import points to your QR orders page file

class OrderListPage extends StatefulWidget {
  final String? cafeUserName;
  const OrderListPage({super.key, this.cafeUserName});

  @override
  _OrderListPageState createState() => _OrderListPageState();
}

class _OrderListPageState extends State<OrderListPage> {
  List<dynamic> allOrders = [];
  List<dynamic> filteredOrders = [];
  Map<String, String> tableCache = {};

  // Filter and search states
  String statusFilter = "ALL";
  String dateFilter = "today";
  DateTime? customStartDate;
  DateTime? customEndDate;

  final TextEditingController _searchController = TextEditingController();
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      fetchOrders();
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  String _resolveCafeUserName() {
    if (widget.cafeUserName != null && widget.cafeUserName!.isNotEmpty) {
      return widget.cafeUserName!;
    }
    final staffAuthProvider = context.read<StaffAuthProvider>();
    final authProvider = context.read<AuthProvider>();

    return staffAuthProvider.staffDetails?['cafeUserName'] ??
        authProvider.user?.cafeUserName ??
        "cafe123456";
  }

  Future<String?> _resolveAccessToken() async {
    final staffAuthProvider = context.read<StaffAuthProvider>();
    final authProvider = context.read<AuthProvider>();
    return staffAuthProvider.staffDetails != null ? null : authProvider.accessToken;
  }

  Future<void> fetchOrders() async {
    setState(() => isLoading = true);
    final cafeUserName = _resolveCafeUserName();

    try {
      String queryParams = '?filter=$dateFilter';
      if (dateFilter == 'custom' && customStartDate != null && customEndDate != null) {
        String startStr = customStartDate!.toIso8601String().split('T')[0];
        String endStr = customEndDate!.toIso8601String().split('T')[0];
        queryParams += '&startDate=$startStr&endDate=$endStr';
      }

      final String? accessToken = await _resolveAccessToken();

      final response = await http.get(
        Uri.parse('${AppConfig.baseUrl}/order/$cafeUserName$queryParams'),
        headers: {
          "Content-Type": "application/json",
          if (accessToken != null) 'Authorization': 'Bearer $accessToken',
        },
      );

      if (response.statusCode == 200) {
        final body = jsonDecode(response.body);
        if (mounted) {
          setState(() {
            allOrders = body['data'] ?? [];
            applyFilters();
            isLoading = false;
          });
          for (var order in allOrders) {
            if (order['table'] != null) {
              fetchTableName(order['table'].toString());
            }
          }
        }
      } else {
        if (mounted) setState(() => isLoading = false);
      }
    } catch (e) {
      debugPrint("Fetch Error: $e");
      if (mounted) setState(() => isLoading = false);
    }
  }

  Future<void> fetchTableName(String tableId) async {
    if (tableCache.containsKey(tableId)) return;
    try {
      final String? accessToken = await _resolveAccessToken();

      final response = await http.get(
        Uri.parse('${AppConfig.baseUrl}/table/getTable/$tableId'),
        headers: {
          "Content-Type": "application/json",
          if (accessToken != null) 'Authorization': 'Bearer $accessToken',
        },
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (mounted) setState(() => tableCache[tableId] = data['data']['name'] ?? 'Table');
      }
    } catch (e) {
      debugPrint("Table Fetch Error: $e");
    }
  }

  void applyFilters() {
    String searchQuery = _searchController.text.toLowerCase().trim();

    setState(() {
      filteredOrders = allOrders.where((order) {
        bool matchesStatus = statusFilter == "ALL" || order['orderStatus'] == statusFilter;
        String customerName = (order['customerName'] ?? "").toLowerCase();
        bool matchesSearch = customerName.contains(searchQuery);

        return matchesStatus && matchesSearch;
      }).toList();
    });
  }

  Future<void> _selectCustomDateRange() async {
    final DateTimeRange? picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2025),
      lastDate: DateTime.now(),
      initialDateRange: customStartDate != null && customEndDate != null
          ? DateTimeRange(start: customStartDate!, end: customEndDate!)
          : null,
    );

    if (picked != null) {
      setState(() {
        customStartDate = picked.start;
        customEndDate = picked.end;
        dateFilter = 'custom';
      });
      fetchOrders();
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;
    List<String> statusList = ["ALL", "PENDING", "PREPARING", "READY", "SERVED", "COMPLETED"];

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text(
          "Order Management",
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.bold,
            color: isDarkMode ? Colors.white : Colors.black,
          ),
        ),
        elevation: 0,
        backgroundColor: Colors.transparent,
        iconTheme: IconThemeData(color: isDarkMode ? Colors.white : Colors.black87),
        actions: [
          // QR / Web Orders Navigation Button Added Here
          IconButton(
            tooltip: "Incoming QR Orders",
            icon: Stack(
              children: [
                Icon(
                  Icons.qr_code_scanner,
                  color: isDarkMode ? Colors.white : Colors.black87,
                ),
                // Optional small indicator dot
                Positioned(
                  right: 0,
                  top: 0,
                  child: Container(
                    width: 8,
                    height: 8,
                    decoration: const BoxDecoration(
                      color: Colors.indigo,
                      shape: BoxShape.circle,
                    ),
                  ),
                ),
              ],
            ),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => PendingQrOrdersPage(
                    cafeUserName: _resolveCafeUserName(),
                  ),
                ),
              );
            },
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: Column(
        children: [
          // Date Filter Bar & Status Dropdown & Search Bar Container
          Container(
            color: Theme.of(context).cardColor,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Column(
              children: [
                // Horizontal Date Filter Chips
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      _dateChip("Today", "today", isDarkMode),
                      _dateChip("Yesterday", "yesterday", isDarkMode),
                      _dateChip("This Week", "thisWeek", isDarkMode),
                      _dateChip("This Month", "thisMonth", isDarkMode),
                      _dateChip("All", "all", isDarkMode),
                      ActionChip(
                        label: Text(
                          dateFilter == 'custom' && customStartDate != null
                              ? "${customStartDate!.toIso8601String().split('T')[0]} - ${customEndDate!.toIso8601String().split('T')[0]}"
                              : "Custom Range",
                          style: GoogleFonts.poppins(
                            fontSize: 12,
                            color: dateFilter == 'custom' ? Colors.white : (isDarkMode ? Colors.white70 : Colors.black87),
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        backgroundColor: dateFilter == 'custom' ? Colors.indigo : (isDarkMode ? Colors.grey.shade800 : Colors.grey.shade200),
                        onPressed: _selectCustomDateRange,
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),

                // Search Bar and Status Dropdown Row
                Row(
                  children: [
                    // Search Bar
                    Expanded(
                      flex: 3,
                      child: TextField(
                        controller: _searchController,
                        onChanged: (value) => applyFilters(),
                        decoration: InputDecoration(
                          hintText: "Search customer...",
                          hintStyle: GoogleFonts.poppins(fontSize: 13, color: Colors.grey),
                          prefixIcon: const Icon(Icons.search, color: Colors.grey, size: 20),
                          filled: true,
                          fillColor: isDarkMode ? Colors.grey.shade900 : const Color(0xFFF4F6F9),
                          contentPadding: const EdgeInsets.symmetric(vertical: 0, horizontal: 10),
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                        ),
                        style: TextStyle(color: isDarkMode ? Colors.white : Colors.black87),
                      ),
                    ),
                    const SizedBox(width: 10),

                    // Status Dropdown Filter
                    Expanded(
                      flex: 2,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10),
                        decoration: BoxDecoration(
                          color: isDarkMode ? Colors.grey.shade900 : const Color(0xFFF4F6F9),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton<String>(
                            value: statusFilter,
                            isExpanded: true,
                            dropdownColor: Theme.of(context).cardColor,
                            style: GoogleFonts.poppins(
                              fontSize: 12,
                              color: isDarkMode ? Colors.white : Colors.black87,
                              fontWeight: FontWeight.w500,
                            ),
                            items: statusList.map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(),
                            onChanged: (v) {
                              setState(() {
                                statusFilter = v!;
                                applyFilters();
                              });
                            },
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),

          // Orders List View
          Expanded(
            child: isLoading
                ? const Center(
              child: SipSnapAnimatedLogo(fontSize: 22),
            )
                : filteredOrders.isEmpty
                ? Center(
              child: Text(
                "No orders found",
                style: GoogleFonts.poppins(color: Colors.grey.shade500, fontSize: 14),
              ),
            )
                : RefreshIndicator(
              onRefresh: fetchOrders,
              child: ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                itemCount: filteredOrders.length,
                itemBuilder: (context, i) => _buildOrderCard(filteredOrders[i], isDarkMode),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _dateChip(String label, String value, bool isDarkMode) {
    bool isSelected = dateFilter == value;
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ChoiceChip(
        label: Text(label, style: GoogleFonts.poppins(fontSize: 12, fontWeight: FontWeight.w500)),
        selected: isSelected,
        selectedColor: Colors.indigo,
        backgroundColor: isDarkMode ? Colors.grey.shade800 : Colors.grey.shade200,
        labelStyle: TextStyle(color: isSelected ? Colors.white : (isDarkMode ? Colors.white70 : Colors.black87)),
        onSelected: (bool selected) {
          if (selected) {
            setState(() {
              dateFilter = value;
            });
            fetchOrders();
          }
        },
      ),
    );
  }

  Widget _buildOrderCard(dynamic order, bool isDarkMode) {
    bool isCompleted = order['orderStatus'] == "COMPLETED";
    String tableId = order['table'] != null ? order['table'].toString() : '';
    String tableName = tableCache[tableId] ?? "Table";
    String orderId = order['_id'] ?? '';

    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      color: Theme.of(context).cardColor,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      elevation: 3,
      shadowColor: Colors.black.withOpacity(0.05),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  order['customerName'] ?? "Guest",
                  style: GoogleFonts.poppins(fontWeight: FontWeight.bold, fontSize: 17, color: isDarkMode ? Colors.white : Colors.black87),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: isCompleted
                        ? (isDarkMode ? Colors.green.shade900.withOpacity(0.4) : Colors.green.shade50)
                        : (isDarkMode ? Colors.orange.shade900.withOpacity(0.4) : Colors.orange.shade50),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: isCompleted ? Colors.green.shade200 : Colors.orange.shade200,
                    ),
                  ),
                  child: Text(
                    order['orderStatus'] ?? 'PENDING',
                    style: TextStyle(
                      color: isCompleted ? (isDarkMode ? Colors.greenAccent : Colors.green.shade700) : (isDarkMode ? Colors.orangeAccent : Colors.orange.shade700),
                      fontWeight: FontWeight.bold,
                      fontSize: 11,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                const Icon(Icons.table_restaurant, size: 16, color: Colors.indigo),
                const SizedBox(width: 4),
                Text(tableName, style: GoogleFonts.poppins(fontWeight: FontWeight.w600, color: Colors.indigo, fontSize: 13)),
                const SizedBox(width: 16),
                const Icon(Icons.payments_outlined, size: 16, color: Colors.green),
                const SizedBox(width: 4),
                Text(
                  "Rs. ${order['totalPrice'] ?? 0}",
                  style: GoogleFonts.poppins(fontWeight: FontWeight.bold, color: Colors.green, fontSize: 13),
                ),
              ],
            ),
            Divider(height: 24, color: isDarkMode ? Colors.grey.shade800 : Colors.grey.shade200),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _showOrderOptions(order),
                    icon: const Icon(Icons.edit_outlined, size: 16),
                    label: const Text("Status"),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.indigo,
                      side: const BorderSide(color: Colors.indigo),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => OrderItemsPage(orderId: orderId),
                        ),
                      );
                    },
                    icon: const Icon(Icons.visibility_outlined, size: 16, color: Colors.white),
                    label: const Text("Details", style: TextStyle(color: Colors.white)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.indigo,
                      elevation: 0,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _showOrderOptions(dynamic order) {
    String currentStatus = order['orderStatus'];
    List<String> options = ["PENDING", "PREPARING", "READY", "SERVED", "COMPLETED"];
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;

    showModalBottomSheet(
      context: context,
      backgroundColor: Theme.of(context).cardColor,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(25))),
      builder: (context) => StatefulBuilder(builder: (context, setModal) {
        return Container(
          padding: const EdgeInsets.all(25),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text("Update Order Status", style: GoogleFonts.poppins(fontSize: 18, fontWeight: FontWeight.bold, color: isDarkMode ? Colors.white : Colors.black87)),
            const SizedBox(height: 20),
            DropdownButton<String>(
              isExpanded: true,
              dropdownColor: Theme.of(context).cardColor,
              value: options.contains(currentStatus) ? currentStatus : options.first,
              items: options.map((s) => DropdownMenuItem(value: s, child: Text(s, style: TextStyle(color: isDarkMode ? Colors.white : Colors.black)))).toList(),
              onChanged: (v) => setModal(() => currentStatus = v!),
            ),
            const SizedBox(height: 30),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.indigo, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15))),
                onPressed: () async {
                  final cafeUserName = _resolveCafeUserName();
                  final String? accessToken = await _resolveAccessToken();

                  final response = await http.put(
                    Uri.parse('${AppConfig.baseUrl}/order/$cafeUserName'),
                    headers: {
                      "Content-Type": "application/json",
                      if (accessToken != null) 'Authorization': 'Bearer $accessToken',
                    },
                    body: jsonEncode({"orderStatus": currentStatus, "orderId": order['_id']}),
                  );

                  if (response.statusCode == 200) {
                    if (currentStatus == "COMPLETED" && order['table'] != null) {
                      String tableId = order['table'].toString();
                      await http.patch(
                        Uri.parse('${AppConfig.baseUrl}/table/$tableId'),
                        body: jsonEncode({"status": "available"}),
                        headers: {
                          "Content-Type": "application/json",
                          if (accessToken != null) 'Authorization': 'Bearer $accessToken',
                        },
                      );
                    }
                    if (mounted) {
                      Navigator.pop(context);
                      await fetchOrders();
                    }
                  }
                },
                child: const Text("SAVE STATUS", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              ),
            )
          ]),
        );
      }),
    );
  }
}