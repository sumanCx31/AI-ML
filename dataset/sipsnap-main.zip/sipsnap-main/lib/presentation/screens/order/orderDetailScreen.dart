import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../../../core/config/app_config.dart';
import '../../../providers/auth_provider.dart';
import '../../../providers/staff_auth_provider.dart';

class OrderDetailPage extends StatefulWidget {
  final String tableId;
  final String tableName;

  const OrderDetailPage({super.key, required this.tableId, required this.tableName});

  @override
  _OrderDetailPageState createState() => _OrderDetailPageState();
}

class _OrderDetailPageState extends State<OrderDetailPage> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  List<dynamic> allMenus = [];
  List<dynamic> allCategories = [];
  Map<String, int> selectedItems = {};
  bool isLoading = true;
  bool isSubmitting = false; // Added to block multiple submissions

  @override
  void initState() {
    super.initState();
    // debugPrint("--- Debug: OrderDetailPage opened for Table ID: ${widget.tableId} ---");
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _fetchInitialData();
    });
  }

  Future<String> _resolveCafeUserName() async {
    final staffAuthProvider = context.read<StaffAuthProvider>();
    final authProvider = context.read<AuthProvider>();
    return staffAuthProvider.staffDetails?['cafeUserName'] ??
        authProvider.user?.cafeUserName ??
        "cafe123456";
  }

  Future<String?> _resolveAccessToken() async {
    final staffAuthProvider = context.read<StaffAuthProvider>();
    final authProvider = context.read<AuthProvider>();
    return staffAuthProvider.staffDetails != null ? null : authProvider.accessToken;
  }

  Future<void> _fetchInitialData() async {
    await Future.wait([fetchMenu(), fetchCategories()]);
    if (mounted) setState(() => isLoading = false);
  }

  Future<void> fetchMenu() async {
    try {
      final cafeUserName = await _resolveCafeUserName();
      final response = await http.get(Uri.parse('${AppConfig.baseUrl}/menu/cafe/$cafeUserName'));
      if (response.statusCode == 200) {
        allMenus = jsonDecode(response.body)['data'] ?? [];
      }
    } catch (e) {
      debugPrint("Error fetching menu: $e");
    }
  }

  Future<void> fetchCategories() async {
    try {
      final cafeUserName = await _resolveCafeUserName();
      final response = await http.get(Uri.parse('${AppConfig.baseUrl}/category/all/$cafeUserName'));
      if (response.statusCode == 200) {
        allCategories = jsonDecode(response.body)['data'] ?? [];
      }
    } catch (e) {
      debugPrint("Error fetching categories: $e");
    }
  }

  double get totalPrice {
    return selectedItems.entries.fold(0, (sum, entry) {
      var item = allMenus.firstWhere((m) => m['_id'] == entry.key, orElse: () => {'price': 0});
      return sum + ((item['price'] ?? 0) * entry.value);
    });
  }

  void _openMenuGrid(bool isDarkMode) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(25))),
      builder: (context) => MenuGridPicker(
        allMenus: allMenus,
        allCategories: allCategories,
        currentlySelected: selectedItems,
        isDarkMode: isDarkMode,
        onConfirm: (updatedMap) => setState(() => selectedItems = updatedMap),
      ),
    );
  }

  Future<void> submitOrder() async {
    if (isSubmitting) return; // Prevent concurrent calls if already processing

    if (_nameController.text.isEmpty || selectedItems.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Please fill customer details and add items")));
      return;
    }

    setState(() => isSubmitting = true); // Lock the button and show loading

    final cafeUserName = await _resolveCafeUserName();
    final String? accessToken = await _resolveAccessToken();
    debugPrint("CAFE USER NAME:$cafeUserName");

    try {
      final orderResponse = await http.post(
        Uri.parse('${AppConfig.baseUrl}/order'),
        headers: {
          "Content-Type": "application/json",
          if (accessToken != null) 'Authorization': 'Bearer $accessToken',
        },
        body: jsonEncode({
          "customerName": _nameController.text.trim(),
          "customerPhone": _phoneController.text.trim(),
          "cafeUserName": cafeUserName,
          "table": widget.tableId,
          "items": selectedItems.entries.map((e) => {"menu": e.key, "quantity": e.value}).toList(),
        }),
      );

      if (orderResponse.statusCode == 200 || orderResponse.statusCode == 201) {
        await http.patch(
          Uri.parse('${AppConfig.baseUrl}/table/${widget.tableId}'),
          headers: {
            "Content-Type": "application/json",
            if (accessToken != null) 'Authorization': 'Bearer $accessToken',
          },
          body: jsonEncode({"status": "occupied"}),
        );
        if (mounted) {
          Navigator.pop(context);
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Order Successful!")));
        }
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Failed to submit order")));
        }
      }
    } catch (e) {
      debugPrint("Error: $e");
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Failed to submit order")));
      }
    } finally {
      if (mounted) {
        setState(() => isSubmitting = false); // Release the lock whether it succeeds or fails
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text(
          "Order for ${widget.tableName}",
          style: GoogleFonts.poppins(
            color: isDarkMode ? Colors.white : Colors.black,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: IconThemeData(color: isDarkMode ? Colors.white : Colors.black87),
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator(color: Colors.indigo))
          : Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(
              controller: _nameController,
              decoration: InputDecoration(
                labelText: "Customer Name",
                labelStyle: TextStyle(color: Colors.grey.shade500),
                filled: true,
                fillColor: Theme.of(context).cardColor,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
              ),
              style: TextStyle(color: isDarkMode ? Colors.white : Colors.black87),
            ),
            const SizedBox(height: 15),
            TextField(
              controller: _phoneController,
              keyboardType: TextInputType.phone,
              decoration: InputDecoration(
                labelText: "Phone Number",
                labelStyle: TextStyle(color: Colors.grey.shade500),
                filled: true,
                fillColor: Theme.of(context).cardColor,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
              ),
              style: TextStyle(color: isDarkMode ? Colors.white : Colors.black87),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: ListView(
                children: [
                  ...selectedItems.entries.map((entry) {
                    final item = allMenus.firstWhere((m) => m['_id'] == entry.key, orElse: () => {'name': 'Unknown', 'price': 0});
                    return Card(
                      color: Theme.of(context).cardColor,
                      margin: const EdgeInsets.only(bottom: 10),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                      child: ListTile(
                        title: Text(item['name'], style: TextStyle(color: isDarkMode ? Colors.white : Colors.black87, fontWeight: FontWeight.bold)),
                        subtitle: Text("Rs. ${item['price']}", style: TextStyle(color: isDarkMode ? Colors.greenAccent : Colors.green.shade700)),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              icon: Icon(Icons.remove_circle_outline, color: isDarkMode ? Colors.white70 : Colors.black54),
                              onPressed: () => setState(() => selectedItems[entry.key] = (entry.value > 1) ? entry.value - 1 : 0),
                            ),
                            Text("${entry.value}", style: TextStyle(color: isDarkMode ? Colors.white : Colors.black87, fontWeight: FontWeight.bold)),
                            IconButton(
                              icon: Icon(Icons.add_circle_outline, color: isDarkMode ? Colors.white70 : Colors.black54),
                              onPressed: () => setState(() => selectedItems[entry.key] = entry.value + 1),
                            ),
                          ],
                        ),
                      ),
                    );
                  }),
                  TextButton.icon(
                    onPressed: () => _openMenuGrid(isDarkMode),
                    icon: const Icon(Icons.add, color: Colors.indigo),
                    label: const Text("Add Items", style: TextStyle(color: Colors.indigo, fontWeight: FontWeight.bold)),
                  ),
                ],
              ),
            ),
            ElevatedButton(
              onPressed: isSubmitting ? null : submitOrder, // Disables button when submitting
              style: ElevatedButton.styleFrom(
                minimumSize: const Size(double.infinity, 55),
                backgroundColor: Colors.indigo,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
              ),
              child: isSubmitting
                  ? const SizedBox(
                height: 24,
                width: 24,
                child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5),
              )
                  : Text(
                "Total: Rs. ${totalPrice.toStringAsFixed(2)} - Submit Order",
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16),
              ),
            )
          ],
        ),
      ),
    );
  }
}

class MenuGridPicker extends StatefulWidget {
  final List<dynamic> allMenus;
  final List<dynamic> allCategories;
  final Map<String, int> currentlySelected;
  final bool isDarkMode;
  final Function(Map<String, int>) onConfirm;

  const MenuGridPicker({
    super.key,
    required this.allMenus,
    required this.allCategories,
    required this.currentlySelected,
    required this.isDarkMode,
    required this.onConfirm,
  });

  @override
  _MenuGridPickerState createState() => _MenuGridPickerState();
}

class _MenuGridPickerState extends State<MenuGridPicker> {
  Map<String, int> tempSelection = {};
  String selectedCategoryId = 'all';

  @override
  void initState() {
    super.initState();
    tempSelection = Map.from(widget.currentlySelected);
  }

  List<dynamic> get filteredMenus {
    if (selectedCategoryId == 'all') {
      return widget.allMenus;
    }
    return widget.allMenus.where((item) {
      final categoryField = item['category'];
      if (categoryField is Map) {
        return categoryField['_id'] == selectedCategoryId;
      } else if (categoryField is String) {
        return categoryField == selectedCategoryId;
      }
      return false;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final items = filteredMenus;

    return Container(
      height: MediaQuery.of(context).size.height * 0.75,
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          Text(
            "Select Menu Items",
            style: GoogleFonts.poppins(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: widget.isDarkMode ? Colors.white : Colors.black87,
            ),
          ),
          const SizedBox(height: 15),
          SizedBox(
            height: 45,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: [
                _buildCategoryChip('all', 'All'),
                ...widget.allCategories.map((cat) => _buildCategoryChip(cat['_id'], cat['name'])),
              ],
            ),
          ),
          const SizedBox(height: 15),
          Expanded(
            child: items.isEmpty
                ? Center(
              child: Text(
                "No items found in this category",
                style: TextStyle(color: Colors.grey.shade500),
              ),
            )
                : GridView.builder(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                childAspectRatio: 0.9,
              ),
              itemCount: items.length,
              itemBuilder: (context, i) {
                final item = items[i];
                bool isSelected = tempSelection.containsKey(item['_id']);
                final imageUrl = item['image']?['secureUrl'] ?? '';

                return InkWell(
                  onTap: () => setState(() {
                    if (isSelected) {
                      tempSelection.remove(item['_id']);
                    } else {
                      tempSelection[item['_id']] = 1;
                    }
                  }),
                  child: Card(
                    elevation: 2,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                    color: isSelected
                        ? (widget.isDarkMode ? Colors.indigo.shade900.withOpacity(0.5) : Colors.indigo.shade50)
                        : Theme.of(context).cardColor,
                    child: Stack(
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Expanded(
                              child: ClipRRect(
                                borderRadius: const BorderRadius.vertical(top: Radius.circular(15)),
                                child: imageUrl.isNotEmpty
                                    ? Image.network(imageUrl, fit: BoxFit.cover)
                                    : Container(
                                  color: widget.isDarkMode ? Colors.grey.shade900 : Colors.grey.shade200,
                                  child: const Icon(Icons.fastfood, color: Colors.orange),
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    item['name'],
                                    style: TextStyle(
                                      fontWeight: FontWeight.w600,
                                      fontSize: 13,
                                      color: widget.isDarkMode ? Colors.white : Colors.black87,
                                    ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  Text(
                                    "Rs. ${item['price']}",
                                    style: TextStyle(
                                      color: widget.isDarkMode ? Colors.greenAccent : Colors.green.shade700,
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        if (isSelected)
                          const Positioned(
                            top: 8,
                            right: 8,
                            child: Icon(Icons.check_circle, color: Colors.indigo, size: 24),
                          ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 10),
          ElevatedButton(
            onPressed: () {
              widget.onConfirm(tempSelection);
              Navigator.pop(context);
            },
            style: ElevatedButton.styleFrom(
              minimumSize: const Size(double.infinity, 50),
              backgroundColor: Colors.indigo,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
            ),
            child: const Text("Add Selected Items", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          )
        ],
      ),
    );
  }

  Widget _buildCategoryChip(String id, String label) {
    bool isSelected = selectedCategoryId == id;
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ChoiceChip(
        label: Text(label),
        selected: isSelected,
        selectedColor: Colors.indigo,
        backgroundColor: widget.isDarkMode ? Colors.grey.shade800 : Colors.grey.shade200,
        labelStyle: TextStyle(
          color: isSelected ? Colors.white : (widget.isDarkMode ? Colors.white70 : Colors.black87),
          fontWeight: FontWeight.w500,
        ),
        onSelected: (_) {
          setState(() {
            selectedCategoryId = id;
          });
        },
      ),
    );
  }
}