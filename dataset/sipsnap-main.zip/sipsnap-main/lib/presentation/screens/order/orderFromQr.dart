import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../../../core/config/app_config.dart';
import '../../../providers/auth_provider.dart';
import '../../../providers/staff_auth_provider.dart';
import '../../widgets/sipsnap_loading_logo.dar.dart'; // Fixed import typo

class PendingQrOrdersPage extends StatefulWidget {
  final String? cafeUserName;
  const PendingQrOrdersPage({super.key, this.cafeUserName});

  @override
  State<PendingQrOrdersPage> createState() => _PendingQrOrdersPageState();
}

class _PendingQrOrdersPageState extends State<PendingQrOrdersPage> {
  List<dynamic> pendingQrOrders = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchPendingQrOrders();
  }

  Future<String?> _resolveAccessToken() async {
    final staffAuthProvider = context.read<StaffAuthProvider>();
    final authProvider = context.read<AuthProvider>();
    return staffAuthProvider.staffDetails != null ? null : authProvider.accessToken;
  }

  String _resolveCafeUserName() {
    if (widget.cafeUserName != null && widget.cafeUserName!.isNotEmpty) {
      return widget.cafeUserName!;
    }
    final staffAuthProvider = context.read<StaffAuthProvider>();
    final authProvider = context.read<AuthProvider>();
    return staffAuthProvider.staffDetails?['cafeUserName'] ??
        authProvider.user?.cafeUserName ??
        "cafe123456";
  }

  Future<void> _fetchPendingQrOrders() async {
    try {
      final cafeUserName = _resolveCafeUserName();
      final accessToken = await _resolveAccessToken();

      final response = await http.get(
        Uri.parse('http://localhost:9005/api/v1/order-by-qr/pending/$cafeUserName'),
        headers: {
          "Content-Type": "application/json",
          if (accessToken != null) 'Authorization': 'Bearer $accessToken',
        },
      );

      if (response.statusCode == 200) {
        final body = jsonDecode(response.body);
        if (mounted) {
          setState(() {
            pendingQrOrders = body['data'] ?? [];
            isLoading = false;
          });
        }
      } else {
        if (mounted) setState(() => isLoading = false);
      }
    } catch (e) {
      debugPrint("Fetch QR Orders Error: $e");
      if (mounted) setState(() => isLoading = false);
    }
  }

  // Accept Button: Creates live order then calls your /order-by-qr/reject/:id endpoint to clear staging
  Future<void> _acceptOrder(dynamic orderItem) async {
    try {
      final accessToken = await _resolveAccessToken();
      final cafeUserName = _resolveCafeUserName();

      // Format items to only pass menu ID and quantity
      List<Map<String, dynamic>> formattedItems = [];
      for (var item in orderItem['items']) {
        String menuId = item['menu'] is Map ? item['menu']['_id'] : item['menu'];
        formattedItems.add({
          "menu": menuId,
          "quantity": item['quantity'] ?? 1,
        });
      }

      // Safely extract table ID
      String tableId = orderItem['table'] is Map ? orderItem['table']['_id'] : orderItem['table'];

      // 1. Post to your standard order creation route
      final createResponse = await http.post(
        Uri.parse('${AppConfig.baseUrl}/order'),
        headers: {
          "Content-Type": "application/json",
          if (accessToken != null) 'Authorization': 'Bearer $accessToken',
        },
        body: jsonEncode({
          "customerName": orderItem['customerName'] ?? "Guest",
          "customerPhone": orderItem['customerPhone'],
          "cafeUserName": cafeUserName,
          "table": tableId,
          "items": formattedItems,
          "orderBy": "website_qr",
          "paymentMethod": "CASH",
        }),
      );

      // If creation is successful (200 or 201)
      if (createResponse.statusCode == 201 || createResponse.statusCode == 200) {
        final qrOrderId = orderItem['_id'];

        // 2. Call your requested reject/remove route to clean up the staging item
        await http.delete(
          Uri.parse('${AppConfig.baseUrl}/order-by-qr/reject/$qrOrderId'),
          headers: {
            "Content-Type": "application/json",
            if (accessToken != null) 'Authorization': 'Bearer $accessToken',
          },
        );

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("Order accepted and sent to live kitchen!")),
          );
          _fetchPendingQrOrders();
        }
      } else {
        final decoded = jsonDecode(createResponse.body);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(decoded['message'] ?? "Failed to accept order")),
          );
        }
      }
    } catch (e) {
      debugPrint("Accept Order Error: $e");
    }
  }

  // Reject Button: Removes item from the QR staging model
  Future<void> _rejectOrder(String qrOrderId) async {
    try {
      final accessToken = await _resolveAccessToken();
      final response = await http.delete(
        Uri.parse('${AppConfig.baseUrl}/order-by-qr/reject/$qrOrderId'),
        headers: {
          "Content-Type": "application/json",
          if (accessToken != null) 'Authorization': 'Bearer $accessToken',
        },
      );

      if (response.statusCode == 200 || response.statusCode == 204) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("QR order rejected and removed")),
          );
          _fetchPendingQrOrders();
        }
      }
    } catch (e) {
      debugPrint("Reject QR Order Error: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text(
          "Incoming Website / QR Orders",
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.bold,
            color: isDarkMode ? Colors.white : Colors.black87,
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: IconThemeData(color: isDarkMode ? Colors.white : Colors.black87),
      ),
      body: isLoading
          ? const Center(child: SipSnapAnimatedLogo(fontSize: 22))
          : pendingQrOrders.isEmpty
          ? Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.qr_code_scanner, size: 60, color: Colors.grey),
            const SizedBox(height: 12),
            Text(
              "No pending QR requests",
              style: GoogleFonts.poppins(color: Colors.grey.shade500, fontSize: 15),
            ),
          ],
        ),
      )
          : RefreshIndicator(
        onRefresh: _fetchPendingQrOrders,
        child: ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: pendingQrOrders.length,
          itemBuilder: (context, index) {
            final order = pendingQrOrders[index];
            final qrOrderId = order['_id'];
            return _buildQrOrderCard(order, qrOrderId, isDarkMode);
          },
        ),
      ),
    );
  }

  Widget _buildQrOrderCard(dynamic order, String qrOrderId, bool isDarkMode) {
    final tableName = order['table'] != null ? order['table']['name'] : 'N/A';
    final itemsList = order['items'] as List<dynamic>? ?? [];

    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      color: Theme.of(context).cardColor,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      elevation: 3,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  order['customerName'] ?? "Guest Customer",
                  style: GoogleFonts.poppins(fontWeight: FontWeight.bold, fontSize: 17, color: isDarkMode ? Colors.white : Colors.black87),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.amber.shade100,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    "PENDING APPROVAL",
                    style: TextStyle(color: Colors.amber.shade800, fontWeight: FontWeight.bold, fontSize: 10),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              "Phone: ${order['customerPhone'] ?? 'N/A'}",
              style: GoogleFonts.poppins(fontSize: 12, color: Colors.grey),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                const Icon(Icons.table_restaurant, size: 16, color: Colors.indigo),
                const SizedBox(width: 4),
                Text("Table: $tableName", style: GoogleFonts.poppins(fontWeight: FontWeight.w600, color: Colors.indigo, fontSize: 13)),
              ],
            ),
            const SizedBox(height: 10),
            Text("Items Ordered:", style: GoogleFonts.poppins(fontWeight: FontWeight.w600, fontSize: 12, color: Colors.grey.shade600)),
            const SizedBox(height: 4),
            ...itemsList.map((item) {
              final menuName = item['menu'] != null ? item['menu']['name'] : 'Item';
              final qty = item['quantity'] ?? 1;
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 2),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("• $menuName", style: GoogleFonts.poppins(fontSize: 13, color: isDarkMode ? Colors.white70 : Colors.black87)),
                    Text("x$qty", style: GoogleFonts.poppins(fontSize: 13, fontWeight: FontWeight.bold)),
                  ],
                ),
              );
            }),
            const SizedBox(height: 8),
            Text(
              "Auto-deletes in 30 mins if ignored.",
              style: GoogleFonts.poppins(fontSize: 11, color: Colors.red.shade400, fontStyle: FontStyle.italic),
            ),
            Divider(height: 24, color: isDarkMode ? Colors.grey.shade800 : Colors.grey.shade200),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => _rejectOrder(qrOrderId),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.red,
                      side: const BorderSide(color: Colors.red),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                    child: const Text("REJECT"),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () => _acceptOrder(order),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      elevation: 0,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                    child: const Text("ACCEPT", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}