import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'orderDetailScreen.dart';
import 'AddItemPage.dart';
import '../../../core/config/app_config.dart';
import '../../../providers/auth_provider.dart';
import '../../../providers/staff_auth_provider.dart';

class TableSelectionPage extends StatefulWidget {
  const TableSelectionPage({super.key});

  @override
  _TableSelectionPageState createState() => _TableSelectionPageState();
}

class _TableSelectionPageState extends State<TableSelectionPage> {
  List<dynamic> allTables = [];
  List<dynamic> filteredTables = [];
  String searchQuery = "";
  String statusFilter = "ALL";
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      fetchTables();
    });
  }

  Future<void> fetchTables() async {
    setState(() => isLoading = true);

    final staffAuthProvider = context.read<StaffAuthProvider>();
    final authProvider = context.read<AuthProvider>();

    final String cafeUserName = staffAuthProvider.staffDetails?['cafeUserName'] ??
        authProvider.user?.cafeUserName ??
        "cafe123456";

    try {
      final response = await http.get(Uri.parse('${AppConfig.baseUrl}/table/$cafeUserName'));
      debugPrint("Table response: ${response.body}");

      if (response.statusCode == 200) {
        final decoded = jsonDecode(response.body);
        if (mounted) {
          setState(() {
            allTables = decoded['data'] ?? [];
            applyFilters();
            isLoading = false;
          });
        }
      } else {
        if (mounted) setState(() => isLoading = false);
      }
    } catch (e) {
      debugPrint("Error: $e");
      if (mounted) setState(() => isLoading = false);
    }
  }

  void applyFilters() {
    setState(() {
      filteredTables = allTables.where((table) {
        final status = (table['status'] ?? "").toString().toUpperCase();
        final name = (table['name'] ?? "").toString().toLowerCase();
        final matchesSearch = name.contains(searchQuery.toLowerCase());
        final matchesStatus = statusFilter == "ALL" || status == statusFilter.toUpperCase();
        return matchesSearch && matchesStatus;
      }).toList();
    });
  }

  Color _getStatusColor(String status) {
    switch (status.toUpperCase()) {
      case 'AVAILABLE':
        return Colors.green;
      case 'OCCUPIED':
        return Colors.red;
      case 'RESERVED':
        return Colors.redAccent;
      case 'CLEANING':
        return Colors.blue;
      default:
        return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text(
          "Select Table",
          style: GoogleFonts.poppins(
            color: isDarkMode ? Colors.white : Colors.black,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: IconThemeData(color: isDarkMode ? Colors.white : Colors.black87),
      ),
      body: Column(
        children: [
          Container(
            color: Theme.of(context).cardColor,
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                TextField(
                  onChanged: (v) {
                    searchQuery = v;
                    applyFilters();
                  },
                  decoration: InputDecoration(
                    hintText: "Search table name...",
                    hintStyle: TextStyle(color: Colors.grey.shade500),
                    prefixIcon: const Icon(Icons.search, color: Colors.grey),
                    filled: true,
                    fillColor: isDarkMode ? Colors.grey.shade900 : Colors.grey.shade100,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(15),
                      borderSide: BorderSide.none,
                    ),
                  ),
                  style: TextStyle(color: isDarkMode ? Colors.white : Colors.black87),
                ),
                const SizedBox(height: 10),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: ["ALL", "AVAILABLE", "OCCUPIED", "RESERVED", "CLEANING"].map((status) {
                      bool isSelected = statusFilter == status;
                      return Padding(
                        padding: const EdgeInsets.only(right: 8),
                        child: ChoiceChip(
                          label: Text(status),
                          selected: isSelected,
                          selectedColor: Colors.indigo,
                          backgroundColor: isDarkMode ? Colors.grey.shade800 : Colors.grey.shade200,
                          labelStyle: TextStyle(
                            color: isSelected ? Colors.white : (isDarkMode ? Colors.white70 : Colors.black87),
                            fontWeight: FontWeight.w500,
                          ),
                          onSelected: (selected) {
                            setState(() {
                              statusFilter = status;
                              applyFilters();
                            });
                          },
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: isLoading
                ? const Center(child: CircularProgressIndicator(color: Colors.indigo))
                : GridView.builder(
              padding: const EdgeInsets.all(16),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 16,
                mainAxisSpacing: 16,
                childAspectRatio: 1.1,
              ),
              itemCount: filteredTables.length,
              itemBuilder: (context, index) {
                final table = filteredTables[index];
                final String status = (table['status'] ?? "").toUpperCase();
                Color statusColor = _getStatusColor(status);

                return InkWell(
                  onTap: () async {
                    if (status == 'AVAILABLE') {
                      await Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => OrderDetailPage(
                            tableId: table['_id'],
                            tableName: table['name'] ?? "Table",
                          ),
                        ),
                      );
                    } else if (status == 'OCCUPIED') {
                      await Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => AddItemsPage(
                            tableId: table['_id'],
                            tableName: table['name'] ?? "Table",
                          ),
                        ),
                      );
                    }
                    fetchTables();
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      color: statusColor.withOpacity(isDarkMode ? 0.25 : 0.15),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: statusColor, width: 2),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.table_restaurant, color: statusColor, size: 40),
                        const SizedBox(height: 8),
                        Text(
                          table['name'] ?? "Table",
                          style: GoogleFonts.poppins(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                            color: isDarkMode ? Colors.white : Colors.black87,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          status,
                          style: TextStyle(
                            fontSize: 11,
                            color: statusColor,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}