import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../../../core/config/app_config.dart';
import '../../../providers/auth_provider.dart';
import '../../../providers/staff_auth_provider.dart';
import '../../widgets/sipsnap_loading_logo.dar.dart'; // Professional animated logo import

class OrderItemsPage extends StatefulWidget {
  final String orderId;

  const OrderItemsPage({super.key, required this.orderId});

  @override
  State<OrderItemsPage> createState() => _OrderItemsPageState();
}

class _OrderItemsPageState extends State<OrderItemsPage> with SingleTickerProviderStateMixin {
  List<dynamic> _orderItems = [];
  bool _isLoading = true;
  double _grandTotal = 0.0;

  late AnimationController _animController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _fadeAnimation = CurvedAnimation(parent: _animController, curve: Curves.easeInOut);

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _fetchOrderItems();
    });
  }

  @override
  void dispose() {
    _animController.dispose();
    super.dispose();
  }

  Future<String?> _resolveAccessToken() async {
    final staffAuthProvider = context.read<StaffAuthProvider>();
    final authProvider = context.read<AuthProvider>();
    return staffAuthProvider.staffDetails != null ? null : authProvider.accessToken;
  }

  Future<void> _fetchOrderItems() async {
    final String? accessToken = await _resolveAccessToken();

    try {
      final response = await http.get(
        Uri.parse('${AppConfig.baseUrl}/order/getItems/${widget.orderId}'),
        headers: {
          "Content-Type": "application/json",
          if (accessToken != null) 'Authorization': 'Bearer $accessToken',
        },
      );

      if (response.statusCode == 200) {
        final decoded = json.decode(response.body);
        final items = decoded['data'] ?? [];

        double total = 0.0;
        for (var item in items) {
          total += (item['subtotal'] ?? 0.0);
        }

        if (mounted) {
          setState(() {
            _orderItems = items;
            _grandTotal = total;
            _isLoading = false;
          });
          _animController.forward();
        }
      } else {
        if (mounted) setState(() => _isLoading = false);
      }
    } catch (e) {
      debugPrint("Error fetching order items: $e");
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text(
          "Order Details",
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.bold,
            color: isDarkMode ? Colors.white : Colors.black87,
          ),
        ),
        elevation: 0,
        centerTitle: true,
        iconTheme: IconThemeData(color: isDarkMode ? Colors.white : Colors.black87),
        backgroundColor: Colors.transparent,
      ),
      body: _isLoading
          ? const Center(
        // Integrated your professional animated logo loader here
        child: SipSnapAnimatedLogo(fontSize: 22),
      )
          : _orderItems.isEmpty
          ? Center(
        child: Text(
          "No items found for this order",
          style: GoogleFonts.poppins(color: Colors.grey.shade500, fontSize: 16),
        ),
      )
          : FadeTransition(
        opacity: _fadeAnimation,
        child: Column(
          children: [
            // Header Summary Banner
            Container(
              margin: const EdgeInsets.all(16),
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF3F51B5), Color(0xFF303F9F)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.indigo.withOpacity(0.3),
                    blurRadius: 10,
                    offset: const Offset(0, 5),
                  ),
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Order ID", style: GoogleFonts.poppins(color: Colors.white70, fontSize: 12)),
                      const SizedBox(height: 4),
                      Text(
                        widget.orderId.length > 10 ? "${widget.orderId.substring(0, 10)}..." : widget.orderId,
                        style: GoogleFonts.poppins(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14),
                      ),
                    ],
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text("Total Items", style: GoogleFonts.poppins(color: Colors.white70, fontSize: 12)),
                      const SizedBox(height: 4),
                      Text(
                        "${_orderItems.length}",
                        style: GoogleFonts.poppins(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            // Structured Table Container
            Expanded(
              child: Container(
                margin: const EdgeInsets.symmetric(horizontal: 16),
                decoration: BoxDecoration(
                  color: Theme.of(context).cardColor,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.04),
                      blurRadius: 10,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: Column(
                    children: [
                      // Table Header Row
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                        color: isDarkMode ? Colors.indigo.shade900.withOpacity(0.4) : Colors.indigo.shade50,
                        child: Row(
                          children: [
                            SizedBox(width: 35, child: Text("S.N.", style: GoogleFonts.poppins(fontWeight: FontWeight.bold, fontSize: 13, color: isDarkMode ? Colors.indigo.shade200 : Colors.indigo.shade900))),
                            Expanded(flex: 3, child: Text("Item", style: GoogleFonts.poppins(fontWeight: FontWeight.bold, fontSize: 13, color: isDarkMode ? Colors.indigo.shade200 : Colors.indigo.shade900))),
                            Expanded(flex: 1, child: Text("Qty", textAlign: TextAlign.center, style: GoogleFonts.poppins(fontWeight: FontWeight.bold, fontSize: 13, color: isDarkMode ? Colors.indigo.shade200 : Colors.indigo.shade900))),
                            Expanded(flex: 2, child: Text("Price", textAlign: TextAlign.right, style: GoogleFonts.poppins(fontWeight: FontWeight.bold, fontSize: 13, color: isDarkMode ? Colors.indigo.shade200 : Colors.indigo.shade900))),
                            Expanded(flex: 2, child: Text("Total", textAlign: TextAlign.right, style: GoogleFonts.poppins(fontWeight: FontWeight.bold, fontSize: 13, color: isDarkMode ? Colors.indigo.shade200 : Colors.indigo.shade900))),
                          ],
                        ),
                      ),
                      Divider(height: 1, thickness: 1, color: isDarkMode ? Colors.grey.shade800 : const Color(0xFFEEEEEE)),

                      // Table Data Rows List
                      Expanded(
                        child: ListView.separated(
                          padding: EdgeInsets.zero,
                          itemCount: _orderItems.length,
                          separatorBuilder: (context, index) => Divider(height: 1, color: isDarkMode ? Colors.grey.shade800 : const Color(0xFFF1F3F6)),
                          itemBuilder: (context, index) {
                            final entry = _orderItems[index];
                            final menu = entry['menu'] ?? {};
                            final name = menu['name'] ?? 'Unknown';
                            final quantity = entry['quantity'] ?? 0;
                            final price = entry['price'] ?? 0;
                            final subtotal = entry['subtotal'] ?? 0;

                            return Container(
                              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                              child: Row(
                                children: [
                                  // Serial Number
                                  SizedBox(
                                    width: 35,
                                    child: Text(
                                      "${index + 1}.",
                                      style: GoogleFonts.poppins(color: Colors.grey.shade500, fontSize: 13),
                                    ),
                                  ),
                                  // Item Name
                                  Expanded(
                                    flex: 3,
                                    child: Text(
                                      name,
                                      style: GoogleFonts.poppins(
                                        fontWeight: FontWeight.w600,
                                        fontSize: 13.5,
                                        color: isDarkMode ? Colors.white70 : Colors.black87,
                                      ),
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                  // Quantity
                                  Expanded(
                                    flex: 1,
                                    child: Text(
                                      "$quantity",
                                      textAlign: TextAlign.center,
                                      style: GoogleFonts.poppins(
                                        fontWeight: FontWeight.w500,
                                        fontSize: 13,
                                        color: isDarkMode ? Colors.white70 : Colors.black87,
                                      ),
                                    ),
                                  ),
                                  // Unit Price
                                  Expanded(
                                    flex: 2,
                                    child: Text(
                                      "$price",
                                      textAlign: TextAlign.right,
                                      style: GoogleFonts.poppins(color: Colors.grey.shade400, fontSize: 13),
                                    ),
                                  ),
                                  // Total (Subtotal)
                                  Expanded(
                                    flex: 2,
                                    child: Text(
                                      "$subtotal",
                                      textAlign: TextAlign.right,
                                      style: GoogleFonts.poppins(
                                        fontWeight: FontWeight.bold,
                                        color: isDarkMode ? Colors.greenAccent : Colors.green.shade700,
                                        fontSize: 13,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Grand Total Footer Container
            Container(
              margin: const EdgeInsets.fromLTRB(16, 0, 16, 20),
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
              decoration: BoxDecoration(
                color: Theme.of(context).cardColor,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 10,
                    offset: const Offset(0, 4),
                  ),
                ],
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Grand Total",
                    style: GoogleFonts.poppins(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: isDarkMode ? Colors.white : Colors.black87,
                    ),
                  ),
                  Text(
                    "Rs. ${_grandTotal.toStringAsFixed(2)}",
                    style: GoogleFonts.poppins(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.indigo),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}