import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../../../core/config/app_config.dart';
import '../../../providers/auth_provider.dart';
import '../../../providers/staff_auth_provider.dart';

class AddItemsPage extends StatefulWidget {
  final String tableId;
  final String tableName;
  const AddItemsPage({super.key, required this.tableId, required this.tableName});

  @override
  _AddItemsPageState createState() => _AddItemsPageState();
}

class _AddItemsPageState extends State<AddItemsPage> {
  String? orderId;
  List<dynamic> existingItems = [];
  List<dynamic> menuItems = [];
  List<dynamic> cart = [];
  bool isLoading = true;
  bool isSubmittingCart = false;

  // Track item IDs currently being modified (decrease/delete) to prevent double-tapping
  final Set<String> _processingItemIds = {};

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadData();
    });
  }

  Future<void> _loadData() async {
    final staffAuthProvider = context.read<StaffAuthProvider>();
    final authProvider = context.read<AuthProvider>();
    final String? accessToken = staffAuthProvider.staffDetails != null
        ? null
        : authProvider.accessToken;

    try {
      final activeRes = await http.get(
        Uri.parse('${AppConfig.baseUrl}/api/v1/order/active/${widget.tableId}'),
        headers: {
          "Content-Type": "application/json",
          if (accessToken != null) 'Authorization': 'Bearer $accessToken',
        },
      );
      if (activeRes.statusCode == 200) {
        orderId = jsonDecode(activeRes.body)['data']?['_id'];
        if (orderId != null) {
          final itemsRes = await http.get(
            Uri.parse('${AppConfig.baseUrl}/order/getItems/$orderId'),
            headers: {
              "Content-Type": "application/json",
              if (accessToken != null) 'Authorization': 'Bearer $accessToken',
            },
          );
          if (itemsRes.statusCode == 200) {
            setState(() => existingItems = jsonDecode(itemsRes.body)['data'] ?? []);
          }
        }
      }
      final menuRes = await http.get(
        Uri.parse('${AppConfig.baseUrl}/menu'),
        headers: {
          "Content-Type": "application/json",
          if (accessToken != null) 'Authorization': 'Bearer $accessToken',
        },
      );
      if (menuRes.statusCode == 200) {
        setState(() => menuItems = jsonDecode(menuRes.body)['data'] ?? []);
      }
    } catch (e) {
      debugPrint("Error loading data: $e");
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Failed to load table and menu details")),
        );
      }
    } finally {
      if (mounted) setState(() => isLoading = false);
    }
  }

  // --- DECREASE QUANTITY ---
  Future<void> _decreaseQuantity(String menuId) async {
    if (_processingItemIds.contains(menuId)) return;

    setState(() => _processingItemIds.add(menuId));

    try {
      final staffAuthProvider = context.read<StaffAuthProvider>();
      final authProvider = context.read<AuthProvider>();
      final String? accessToken = staffAuthProvider.staffDetails != null
          ? null
          : authProvider.accessToken;

      final res = await http.patch(
        Uri.parse('${AppConfig.baseUrl}/order/decrease-item/$orderId/$menuId'),
        headers: {
          "Content-Type": "application/json",
          if (accessToken != null) 'Authorization': 'Bearer $accessToken',
        },
      );

      if (res.statusCode == 200) {
        _loadData();
      } else {
        if (mounted) {
          final decoded = jsonDecode(res.body);
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(decoded['message'] ?? "Failed to decrease quantity")),
          );
        }
      }
    } catch (e) {
      debugPrint("Error decreasing quantity: $e");
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Network error while decreasing quantity")),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _processingItemIds.remove(menuId));
      }
    }
  }

  // --- DELETE ITEM ---
  Future<void> _deleteItem(String menuId, bool isDarkMode) async {
    bool? confirm = await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Theme.of(context).cardColor,
        title: Text(
          "Remove Item",
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.bold,
            color: isDarkMode ? Colors.white : Colors.black87,
          ),
        ),
        content: Text(
          "Are you sure you want to remove this item?",
          style: GoogleFonts.poppins(color: isDarkMode ? Colors.white70 : Colors.black54),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text("CANCEL", style: TextStyle(color: isDarkMode ? Colors.white70 : Colors.black54)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text("REMOVE", style: GoogleFonts.poppins(color: Colors.red, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );

    if (confirm == true && orderId != null) {
      if (_processingItemIds.contains(menuId)) return;
      setState(() => _processingItemIds.add(menuId));

      try {
        final staffAuthProvider = context.read<StaffAuthProvider>();
        final authProvider = context.read<AuthProvider>();
        final String? accessToken = staffAuthProvider.staffDetails != null
            ? null
            : authProvider.accessToken;

        final res = await http.delete(
          Uri.parse('${AppConfig.baseUrl}/order/delete-item/$orderId/$menuId'),
          headers: {
            "Content-Type": "application/json",
            if (accessToken != null) 'Authorization': 'Bearer $accessToken',
          },
        );

        if (res.statusCode == 200) {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text("Item removed successfully")),
            );
          }
          _loadData();
        } else {
          if (mounted) {
            final decoded = jsonDecode(res.body);
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(decoded['message'] ?? "Failed to remove item")),
            );
          }
        }
      } catch (e) {
        debugPrint("Error deleting item: $e");
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("Network error while deleting item")),
          );
        }
      } finally {
        if (mounted) {
          setState(() => _processingItemIds.remove(menuId));
        }
      }
    }
  }

  // --- BROWSE MENU WITH QUANTITY DIALOG ---
  void _promptQuantity(dynamic item, bool isDarkMode) {
    int qty = 1;
    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          backgroundColor: Theme.of(context).cardColor,
          title: Text(
            "Select Quantity",
            style: GoogleFonts.poppins(
              fontWeight: FontWeight.bold,
              color: isDarkMode ? Colors.white : Colors.black87,
            ),
          ),
          content: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              IconButton(
                icon: const Icon(Icons.remove_circle, color: Colors.orange),
                onPressed: () => setDialogState(() => qty = qty > 1 ? qty - 1 : 1),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Text(
                  "$qty",
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: isDarkMode ? Colors.white : Colors.black87,
                  ),
                ),
              ),
              IconButton(
                icon: const Icon(Icons.add_circle, color: Colors.green),
                onPressed: () => setDialogState(() => qty++),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text("CANCEL", style: TextStyle(color: isDarkMode ? Colors.white70 : Colors.black54)),
            ),
            ElevatedButton(
              onPressed: () {
                setState(() => cart.add({...item, 'qty': qty}));
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text("Added ${item['name']} to pending list"), duration: const Duration(seconds: 1)),
                );
              },
              child: const Text("ADD TO LIST"),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _confirmAdditions() async {
    if (orderId == null || cart.isEmpty || isSubmittingCart) return;

    setState(() => isSubmittingCart = true);

    try {
      final staffAuthProvider = context.read<StaffAuthProvider>();
      final authProvider = context.read<AuthProvider>();
      final String? accessToken = staffAuthProvider.staffDetails != null
          ? null
          : authProvider.accessToken;

      final payload = {"items": cart.map((i) => {"menu": i['_id'], "quantity": i['qty']}).toList()};
      final res = await http.patch(
        Uri.parse('${AppConfig.baseUrl}/order/update-items/$orderId'),
        headers: {
          "Content-Type": "application/json",
          if (accessToken != null) 'Authorization': 'Bearer $accessToken',
        },
        body: jsonEncode(payload),
      );

      if (res.statusCode == 200) {
        setState(() => cart.clear());
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("Items sent to kitchen successfully!")),
          );
        }
        _loadData();
      } else {
        if (mounted) {
          final decoded = jsonDecode(res.body);
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(decoded['message'] ?? "Failed to send items to kitchen")),
          );
        }
      }
    } catch (e) {
      debugPrint("Error confirming additions: $e");
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Network error while communicating with server")),
        );
      }
    } finally {
      if (mounted) setState(() => isSubmittingCart = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text(
          widget.tableName,
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.bold,
            color: isDarkMode ? Colors.white : Colors.black87,
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: IconThemeData(color: isDarkMode ? Colors.white : Colors.black87),
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator(color: Colors.indigo))
          : ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _sectionTitle("CURRENT ORDER", isDarkMode),
          if (existingItems.isEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 20),
              child: Center(
                child: Text(
                  "No active items for this table yet.",
                  style: TextStyle(color: isDarkMode ? Colors.white60 : Colors.grey.shade500),
                ),
              ),
            ),
          ...existingItems.map((i) {
            final menuId = i['menu']?['_id'] ?? '';
            final isProcessing = _processingItemIds.contains(menuId);

            return Card(
              color: Theme.of(context).cardColor,
              elevation: 1,
              margin: const EdgeInsets.only(bottom: 10),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
              child: ListTile(
                leading: ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Image.network(
                    i['menu']?['image']?['optimizedUrl'] ?? '',
                    width: 50,
                    height: 50,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(
                      color: isDarkMode ? Colors.grey.shade900 : Colors.grey.shade200,
                      child: const Icon(Icons.fastfood, color: Colors.grey),
                    ),
                  ),
                ),
                title: Text(
                  i['menu']?['name'] ?? 'Unknown',
                  style: GoogleFonts.poppins(
                    fontWeight: FontWeight.w600,
                    color: isDarkMode ? Colors.white : Colors.black87,
                  ),
                ),
                subtitle: Text(
                  "Qty: ${i['quantity']} | Rs. ${i['subtotal']}",
                  style: TextStyle(color: isDarkMode ? Colors.white70 : Colors.black54),
                ),
                trailing: isProcessing
                    ? const SizedBox(
                  width: 24,
                  height: 24,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
                    : Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.remove_circle_outline, color: Colors.orange),
                      onPressed: menuId.isEmpty ? null : () => _decreaseQuantity(menuId),
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
                      onPressed: menuId.isEmpty ? null : () => _deleteItem(menuId, isDarkMode),
                    ),
                  ],
                ),
              ),
            );
          }),
          if (cart.isNotEmpty) ...[
            const SizedBox(height: 10),
            _sectionTitle("PENDING ADDITIONS", isDarkMode),
            ...cart.asMap().entries.map((entry) {
              final index = entry.key;
              final i = entry.value;

              return Card(
                color: isDarkMode ? Colors.orange.shade900.withOpacity(0.3) : Colors.orange.shade50,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                margin: const EdgeInsets.only(bottom: 8),
                child: ListTile(
                  title: Text(
                    i['name'],
                    style: TextStyle(
                      color: isDarkMode ? Colors.white : Colors.black87,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  subtitle: Text(
                    "Rs. ${i['price']}",
                    style: TextStyle(color: isDarkMode ? Colors.white70 : Colors.black54, fontSize: 12),
                  ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        "Qty: ${i['qty']}",
                        style: TextStyle(
                          color: isDarkMode ? Colors.white70 : Colors.black87,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(width: 8),
                      IconButton(
                        icon: const Icon(Icons.close, size: 18, color: Colors.red),
                        onPressed: () {
                          setState(() => cart.removeAt(index));
                        },
                      ),
                    ],
                  ),
                ),
              );
            }),
          ],
          const SizedBox(height: 100),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showMenuModal(isDarkMode),
        backgroundColor: isDarkMode ? Colors.grey.shade800 : Colors.black,
        label: Text(
          "BROWSE MENU",
          style: GoogleFonts.poppins(fontWeight: FontWeight.bold, color: Colors.white),
        ),
        icon: const Icon(Icons.menu_book, color: Colors.white),
      ),
      bottomNavigationBar: cart.isEmpty
          ? null
          : Padding(
        padding: const EdgeInsets.all(16),
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.green,
            padding: const EdgeInsets.symmetric(vertical: 16),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          ),
          onPressed: isSubmittingCart ? null : _confirmAdditions,
          child: isSubmittingCart
              ? const SizedBox(
            width: 20,
            height: 20,
            child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
          )
              : Text(
            "CONFIRM TO KITCHEN",
            style: GoogleFonts.poppins(fontWeight: FontWeight.bold, color: Colors.white),
          ),
        ),
      ),
    );
  }

  Widget _sectionTitle(String title, bool isDarkMode) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 10),
    child: Text(
      title,
      style: GoogleFonts.poppins(
        fontWeight: FontWeight.bold,
        color: isDarkMode ? Colors.white70 : Colors.grey.shade600,
      ),
    ),
  );

  void _showMenuModal(bool isDarkMode) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: 0.8,
        minChildSize: 0.5,
        maxChildSize: 0.95,
        expand: false,
        builder: (_, scrollController) => Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Text(
                "Select Items",
                style: GoogleFonts.poppins(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: isDarkMode ? Colors.white : Colors.black87,
                ),
              ),
            ),
            Expanded(
              child: ListView.builder(
                controller: scrollController,
                itemCount: menuItems.length,
                itemBuilder: (_, i) => Card(
                  color: Theme.of(context).cardColor,
                  margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  child: ListTile(
                    leading: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.network(
                        menuItems[i]['image']?['optimizedUrl'] ?? '',
                        width: 50,
                        height: 50,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          color: isDarkMode ? Colors.grey.shade900 : Colors.grey.shade200,
                          child: const Icon(Icons.fastfood, color: Colors.grey),
                        ),
                      ),
                    ),
                    title: Text(
                      menuItems[i]['name'],
                      style: TextStyle(
                        color: isDarkMode ? Colors.white : Colors.black87,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    subtitle: Text(
                      "Rs. ${menuItems[i]['price']}",
                      style: TextStyle(color: isDarkMode ? Colors.greenAccent : Colors.green.shade700),
                    ),
                    trailing: const Icon(Icons.add_circle, color: Colors.green),
                    onTap: () => _promptQuantity(menuItems[i], isDarkMode),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}