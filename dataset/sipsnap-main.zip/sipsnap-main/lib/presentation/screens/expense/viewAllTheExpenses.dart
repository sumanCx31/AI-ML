import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:animate_do/animate_do.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../../../providers/auth_provider.dart';
import '../../../providers/staff_auth_provider.dart';
import '../../../core/config/app_config.dart';

class ExpensePage extends StatefulWidget {
  final String? cafeUserName;

  const ExpensePage({
    super.key,
    this.cafeUserName,
  });

  @override
  State<ExpensePage> createState() => _ExpensePageState();
}

class _ExpensePageState extends State<ExpensePage> {
  bool _isLoading = true;
  List<dynamic> _expenseList = [];
  List<dynamic> _filteredExpenseList = [];
  final TextEditingController _searchController = TextEditingController();

  // Filter States
  String _selectedFilter = 'All'; // All, Today, Yesterday, Custom
  DateTime? _selectedDate;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _fetchExpenses();
    });
    _searchController.addListener(_applyFilters);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  String _resolveCafeUserName() {
    if (widget.cafeUserName != null && widget.cafeUserName!.isNotEmpty) {
      return widget.cafeUserName!;
    }
    final staffAuthProvider = context.read<StaffAuthProvider>();
    final authProvider = context.read<AuthProvider>();

    final resolved = staffAuthProvider.staffDetails?['cafeUserName'] ??
        authProvider.user?['cafeUserName'] ??
        "";

    // debugPrint("I AM THE CAFEUSERNAME: $resolved");
    return resolved;
  }

  // Resolves the exact user handle/username required for "addedBy" (e.g., "sam123")
  String _resolveAddedBy() {
    final staffAuthProvider = context.read<StaffAuthProvider>();
    final authProvider = context.read<AuthProvider>();

    return staffAuthProvider.staffDetails?['userName'] ??
        staffAuthProvider.staffDetails?['username'] ??
        staffAuthProvider.staffDetails?['name'] ??
        authProvider.user?['username'] ??
        authProvider.user?['name'] ??
        "staff";
  }

  Future<String?> _resolveAccessToken() async {
    final staffAuthProvider = context.read<StaffAuthProvider>();
    final authProvider = context.read<AuthProvider>();

    return staffAuthProvider.staffDetails != null
        ? null
        : authProvider.accessToken;
  }

  Future<void> _fetchExpenses() async {
    final cafeUserName = _resolveCafeUserName();
    final accessToken = await _resolveAccessToken();

    if (cafeUserName.isEmpty) {
      if (mounted) setState(() => _isLoading = false);
      return;
    }

    try {
      final url = Uri.parse('${AppConfig.baseUrl}/expense/cafe/$cafeUserName');

      final response = await http.get(
        url,
        headers: {
          'Content-Type': 'application/json',
          if (accessToken != null) 'Authorization': 'Bearer $accessToken',
        },
      );

      if (response.statusCode == 200) {
        final decoded = jsonDecode(response.body);
        if (mounted) {
          setState(() {
            _expenseList = decoded['data'] ?? [];
            _applyFilters();
            _isLoading = false;
          });
        }
      } else {
        if (mounted) setState(() => _isLoading = false);
      }
    } catch (e) {
      if (mounted) setState(() => _isLoading = false);
      debugPrint("Error fetching expenses: $e");
    }
  }

  Future<void> _createExpense({
    required String itemName,
    required double price,
    required String description,
  }) async {
    final accessToken = await _resolveAccessToken();
    final cafeUserName = _resolveCafeUserName();
    final addedBy = _resolveAddedBy();

    // Validate that cafeUserName is present before sending
    if (cafeUserName.isEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Error: Cafe username context is missing. Please log in again.")),
        );
      }
      return;
    }

    try {
      final url = Uri.parse('${AppConfig.baseUrl}/expense');

      final Map<String, dynamic> requestBody = {
        "itemName": itemName,
        "price": price,
        "description": description,
        "addedBy": addedBy,
        "cafeUserName": cafeUserName, // FIXED: Now uses the resolved dynamic value
      };

      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
          if (accessToken != null && accessToken.isNotEmpty)
            'Authorization': 'Bearer $accessToken',
        },
        body: jsonEncode(requestBody),
      );

      final decoded = jsonDecode(response.body);

      if (response.statusCode == 201) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(decoded['message'] ?? "Expense recorded successfully")),
          );
          _fetchExpenses();
        }
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(decoded['message'] ?? "Failed to record expense")),
          );
        }
      }
    } catch (e) {
      debugPrint("Error recording expense: $e");
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Network error while recording expense")),
        );
      }
    }
  }

  void _applyFilters() {
    final query = _searchController.text.toLowerCase();
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final yesterday = today.subtract(const Duration(days: 1));

    setState(() {
      _filteredExpenseList = _expenseList.where((expense) {
        final itemName = (expense['itemName'] ?? '').toLowerCase();
        final addedBy = (expense['addedBy'] ?? '').toLowerCase();
        final description = (expense['description'] ?? '').toLowerCase();
        final matchesSearch = itemName.contains(query) || addedBy.contains(query) || description.contains(query);

        if (!matchesSearch) return false;

        final dateStr = expense['createdAt'] ?? expense['date'] ?? expense['timestamp'];
        if (dateStr == null) {
          return _selectedFilter == 'All';
        }

        final expenseDateParsed = DateTime.tryParse(dateStr);
        if (expenseDateParsed == null) return _selectedFilter == 'All';

        final expenseDay = DateTime(expenseDateParsed.year, expenseDateParsed.month, expenseDateParsed.day);

        if (_selectedFilter == 'Today') {
          return expenseDay.isAtSameMomentAs(today);
        } else if (_selectedFilter == 'Yesterday') {
          return expenseDay.isAtSameMomentAs(yesterday);
        } else if (_selectedFilter == 'Custom' && _selectedDate != null) {
          final customDay = DateTime(_selectedDate!.year, _selectedDate!.month, _selectedDate!.day);
          return expenseDay.isAtSameMomentAs(customDay);
        }

        return true;
      }).toList();
    });
  }

  double get _totalFilteredExpense {
    double total = 0.0;
    for (var expense in _filteredExpenseList) {
      final price = expense['price'];
      if (price is num) {
        total += price.toDouble();
      } else if (price is String) {
        total += double.tryParse(price) ?? 0.0;
      }
    }
    return total;
  }

  void _showAddExpenseModal(bool isDarkMode) {
    final itemNameController = TextEditingController();
    final priceController = TextEditingController();
    final descriptionController = TextEditingController();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(context).viewInsets.bottom,
          left: 20,
          right: 20,
          top: 25,
        ),
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(30)),
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade600,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Text(
                "Add New Expense",
                style: GoogleFonts.poppins(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: isDarkMode ? Colors.white : Colors.black87,
                ),
              ),
              const SizedBox(height: 20),
              _buildTextField("Item Name", itemNameController, PhosphorIcons.tag, isDarkMode),
              const SizedBox(height: 15),
              _buildTextField("Price", priceController, PhosphorIcons.currencyDollar, isDarkMode, keyboardType: const TextInputType.numberWithOptions(decimal: true)),
              const SizedBox(height: 15),
              _buildTextField("Description", descriptionController, PhosphorIcons.notepad, isDarkMode, maxLines: 3),
              const SizedBox(height: 30),
              SizedBox(
                width: double.infinity,
                height: 55,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF6366F1),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    elevation: 0,
                  ),
                  onPressed: () async {
                    final price = double.tryParse(priceController.text.trim()) ?? 0.0;
                    if (itemNameController.text.trim().isEmpty || price <= 0) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text("Please provide a valid item name and price")),
                      );
                      return;
                    }

                    Navigator.pop(context);
                    await _createExpense(
                      itemName: itemNameController.text.trim(),
                      price: price,
                      description: descriptionController.text.trim(),
                    );
                  },
                  child: Text(
                    "Save Expense",
                    style: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.w600, color: Colors.white),
                  ),
                ),
              ),
              const SizedBox(height: 30),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(String label, TextEditingController controller, IconData icon, bool isDarkMode, {TextInputType keyboardType = TextInputType.text, int maxLines = 1}) {
    return TextField(
      controller: controller,
      keyboardType: keyboardType,
      maxLines: maxLines,
      style: TextStyle(color: isDarkMode ? Colors.white : Colors.black87),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: TextStyle(color: isDarkMode ? Colors.white70 : Colors.black54),
        prefixIcon: Padding(
          padding: EdgeInsets.only(bottom: maxLines > 1 ? 40.0 : 0.0),
          child: Icon(icon, color: Colors.indigo),
        ),
        alignLabelWithHint: true,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
        filled: true,
        fillColor: isDarkMode ? Colors.grey.shade900 : const Color(0xFFF8F9FE),
      ),
    );
  }

  void _showDescriptionDialog(String itemName, String description, String addedBy, dynamic price, bool isDarkMode) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Theme.of(context).cardColor,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(
          children: [
            const Icon(PhosphorIcons.receipt, color: Colors.indigo),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                itemName,
                style: GoogleFonts.poppins(
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                  color: isDarkMode ? Colors.white : Colors.black87,
                ),
              ),
            ),
          ],
        ),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                "Rs. $price",
                style: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.indigoAccent),
              ),
              const SizedBox(height: 12),
              Text(
                "Description:",
                style: GoogleFonts.poppins(fontWeight: FontWeight.w600, fontSize: 13, color: isDarkMode ? Colors.white70 : Colors.grey.shade700),
              ),
              const SizedBox(height: 4),
              Text(
                description.isEmpty ? 'No description provided' : description,
                style: GoogleFonts.poppins(fontSize: 14, color: isDarkMode ? Colors.white : Colors.black87),
              ),
              const SizedBox(height: 16),
              Text(
                "Added by: @$addedBy",
                style: GoogleFonts.poppins(fontSize: 12, fontWeight: FontWeight.w500, color: isDarkMode ? Colors.white60 : Colors.grey.shade500),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Close", style: GoogleFonts.poppins(fontWeight: FontWeight.w600, color: Colors.indigoAccent)),
          ),
        ],
      ),
    );
  }

  Future<void> _selectCustomDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate ?? DateTime.now(),
      firstDate: DateTime(2023),
      lastDate: DateTime.now(),
    );
    if (picked != null) {
      setState(() {
        _selectedFilter = 'Custom';
        _selectedDate = picked;
        _applyFilters();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text(
          "Cafe Expenses",
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.bold,
            color: isDarkMode ? Colors.white : Colors.black87,
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        iconTheme: IconThemeData(color: isDarkMode ? Colors.white : Colors.black87),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            children: [
              const SizedBox(height: 10),
              // Search & Add Button Row
              Row(
                children: [
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                        color: Theme.of(context).cardColor,
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(isDarkMode ? 0.2 : 0.04),
                            blurRadius: 10,
                          ),
                        ],
                      ),
                      child: TextField(
                        controller: _searchController,
                        style: TextStyle(color: isDarkMode ? Colors.white : Colors.black87),
                        decoration: InputDecoration(
                          hintText: "Search item, description, or user...",
                          hintStyle: TextStyle(color: isDarkMode ? Colors.white60 : Colors.grey.shade400, fontSize: 14),
                          prefixIcon: const Icon(PhosphorIcons.magnifyingGlass, color: Colors.indigo),
                          border: InputBorder.none,
                          contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Container(
                    height: 52,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(colors: [Color(0xFF6366F1), Color(0xFFA855F7)]),
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [BoxShadow(color: Colors.indigo.withOpacity(0.3), blurRadius: 10, offset: const Offset(0, 4))],
                    ),
                    child: IconButton(
                      icon: const Icon(Icons.add, color: Colors.white, size: 26),
                      onPressed: () => _showAddExpenseModal(isDarkMode),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 15),
              // Date Filter Chips Row
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    _buildFilterChip('All', 'All', isDarkMode),
                    const SizedBox(width: 8),
                    _buildFilterChip('Today', 'Today', isDarkMode),
                    const SizedBox(width: 8),
                    _buildFilterChip('Yesterday', 'Yesterday', isDarkMode),
                    const SizedBox(width: 8),
                    ActionChip(
                      avatar: const Icon(PhosphorIcons.calendarBlank, size: 16, color: Colors.indigo),
                      label: Text(
                        _selectedFilter == 'Custom' && _selectedDate != null
                            ? DateFormat('MMM dd, yyyy').format(_selectedDate!)
                            : 'Specific Date',
                        style: GoogleFonts.poppins(
                          fontSize: 13,
                          fontWeight: FontWeight.w500,
                          color: _selectedFilter == 'Custom' ? Colors.white : (isDarkMode ? Colors.white70 : Colors.black87),
                        ),
                      ),
                      backgroundColor: _selectedFilter == 'Custom' ? Colors.indigo : Theme.of(context).cardColor,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      onPressed: _selectCustomDate,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 15),
              // Total Expense Summary Card
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [Color(0xFF6366F1), Color(0xFFA855F7)]),
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [BoxShadow(color: Colors.indigo.withOpacity(0.2), blurRadius: 10, offset: const Offset(0, 4))],
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Total Expense (${_selectedFilter == 'Custom' && _selectedDate != null ? DateFormat('MMM dd').format(_selectedDate!) : _selectedFilter})",
                          style: GoogleFonts.poppins(color: Colors.white70, fontSize: 13, fontWeight: FontWeight.w500),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          "Rs. ${_totalFilteredExpense.toStringAsFixed(2)}",
                          style: GoogleFonts.poppins(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                    const CircleAvatar(
                      radius: 22,
                      backgroundColor: Colors.white24,
                      child: Icon(PhosphorIcons.currencyDollar, color: Colors.white, size: 24),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 15),
              // Expense List
              Expanded(
                child: _isLoading
                    ? const Center(child: CircularProgressIndicator(color: Colors.indigo))
                    : _filteredExpenseList.isEmpty
                    ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(PhosphorIcons.receipt, size: 60, color: Colors.grey.shade600),
                      const SizedBox(height: 10),
                      Text(
                        "No expense records found",
                        style: GoogleFonts.poppins(color: isDarkMode ? Colors.white60 : Colors.grey.shade500, fontSize: 16),
                      ),
                    ],
                  ),
                )
                    : ListView.builder(
                  itemCount: _filteredExpenseList.length,
                  itemBuilder: (context, index) {
                    final expense = _filteredExpenseList[index];
                    final description = expense['description'] ?? '';
                    final itemName = expense['itemName'] ?? 'Unknown';
                    final price = expense['price'] ?? 0;
                    final addedBy = expense['addedBy'] ?? 'Unknown';

                    return FadeInUp(
                      delay: Duration(milliseconds: index * 50),
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 15),
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Theme.of(context).cardColor,
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(isDarkMode ? 0.2 : 0.04),
                              blurRadius: 10,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            CircleAvatar(
                              radius: 24,
                              backgroundColor: isDarkMode ? Colors.indigo.shade900.withOpacity(0.5) : Colors.indigo.shade50,
                              child: const Icon(PhosphorIcons.receipt, color: Colors.indigo, size: 22),
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Expanded(
                                        child: Text(
                                          itemName,
                                          style: GoogleFonts.poppins(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 16,
                                            color: isDarkMode ? Colors.white : Colors.black87,
                                          ),
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                      const SizedBox(width: 8),
                                      Text(
                                        "Rs. $price",
                                        style: GoogleFonts.poppins(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.indigoAccent),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 4),
                                  if (description.isNotEmpty) ...[
                                    Text(
                                      description,
                                      style: TextStyle(color: isDarkMode ? Colors.white70 : Colors.grey.shade600, fontSize: 13),
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                    const SizedBox(height: 4),
                                    if (description.length > 50)
                                      InkWell(
                                        onTap: () => _showDescriptionDialog(itemName, description, addedBy, price, isDarkMode),
                                        child: Text(
                                          "View More",
                                          style: GoogleFonts.poppins(color: Colors.indigoAccent, fontSize: 12, fontWeight: FontWeight.w600),
                                        ),
                                      ),
                                  ],
                                  const SizedBox(height: 6),
                                  Text(
                                    "Added by: @$addedBy",
                                    style: TextStyle(color: isDarkMode ? Colors.white60 : Colors.grey.shade400, fontSize: 11, fontWeight: FontWeight.w500),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFilterChip(String label, String filterKey, bool isDarkMode) {
    final isSelected = _selectedFilter == filterKey;
    return ChoiceChip(
      label: Text(
        label,
        style: GoogleFonts.poppins(
          fontSize: 13,
          fontWeight: FontWeight.w500,
          color: isSelected ? Colors.white : (isDarkMode ? Colors.white70 : Colors.black87),
        ),
      ),
      selected: isSelected,
      selectedColor: Colors.indigo,
      backgroundColor: Theme.of(context).cardColor,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      onSelected: (selected) {
        if (selected) {
          setState(() {
            _selectedFilter = filterKey;
            if (filterKey != 'Custom') {
              _selectedDate = null;
            }
            _applyFilters();
          });
        }
      },
    );
  }
}