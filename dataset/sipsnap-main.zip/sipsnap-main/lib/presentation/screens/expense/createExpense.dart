import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';
import '../../../providers/auth_provider.dart';
import '../../../providers/staff_auth_provider.dart';
import '../../../core/config/app_config.dart';

class CreateExpensePage extends StatefulWidget {
  const CreateExpensePage({super.key});

  @override
  State<CreateExpensePage> createState() => _CreateExpensePageState();
}

class _CreateExpensePageState extends State<CreateExpensePage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _itemNameController = TextEditingController();
  final TextEditingController _priceController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  bool _isSubmitting = false;

  @override
  void dispose() {
    _itemNameController.dispose();
    _priceController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  Future<String?> _resolveAccessToken() async {
    final staffAuthProvider = context.read<StaffAuthProvider>();
    final authProvider = context.read<AuthProvider>();

    return staffAuthProvider.staffDetails != null
        ? null
        : authProvider.accessToken;
  }

  String _resolveCafeUserName() {
    final staffAuthProvider = context.read<StaffAuthProvider>();
    final authProvider = context.read<AuthProvider>();

    if (staffAuthProvider.staffDetails != null) {
      return staffAuthProvider.staffDetails!['cafeUserName'] ??
          staffAuthProvider.staffDetails!['cafe'] ?? '';
    }

    final user = authProvider.user;
    if (user != null) {
      return user['cafeUserName'] ?? user['username'] ?? '';
    }

    return '';
  }

  String _resolveAddedBy() {
    final staffAuthProvider = context.read<StaffAuthProvider>();
    final authProvider = context.read<AuthProvider>();

    if (staffAuthProvider.staffDetails != null) {
      return staffAuthProvider.staffDetails!['username'] ??
          staffAuthProvider.staffDetails!['name'] ?? 'staff';
    }

    final user = authProvider.user;
    if (user != null) {
      return user['username'] ?? user['name'] ?? 'admin';
    }

    return 'user';
  }

  Future<void> _submitExpense() async {
    if (!_formKey.currentState!.validate()) return;

    final cafeUserName = _resolveCafeUserName();
    final addedBy = _resolveAddedBy();

    if (cafeUserName.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Error: Could not determine cafe user name from session."),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    setState(() => _isSubmitting = true);
    final accessToken = await _resolveAccessToken();

    try {
      final url = Uri.parse('${AppConfig.baseUrl}/expense');

      final Map<String, dynamic> requestBody = {
        "itemName": _itemNameController.text.trim(),
        "price": double.tryParse(_priceController.text.trim()) ?? 0.0,
        "description": _descriptionController.text.trim(),
        "addedBy": addedBy,
        "cafeUserName": cafeUserName,
      };

      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
          if (accessToken != null && accessToken.isNotEmpty)
            'Authorization': 'Bearer $accessToken',
        },
        body: jsonEncode(requestBody),
      );

      final decoded = jsonDecode(response.body);

      if (!mounted) return;

      if (response.statusCode == 201) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(decoded['message'] ?? "Expense recorded successfully"),
            backgroundColor: const Color(0xFF5D4037),
          ),
        );
        Navigator.pop(context, true); // Triggers list refresh in ExpensePage
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(decoded['message'] ?? "Failed to record expense"),
            backgroundColor: Colors.red.shade700,
          ),
        );
      }
    } catch (e) {
      debugPrint("Error recording expense: $e");
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text("Network error while recording expense"),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isSubmitting = false);
      }
    }
  }

  Widget _buildTextField(
      String label,
      TextEditingController controller,
      IconData icon, {
        TextInputType keyboardType = TextInputType.text,
        int maxLines = 1,
        String? Function(String?)? validator,
      }) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      maxLines: maxLines,
      validator: validator,
      style: const TextStyle(color: Color(0xFF3E2723)),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(color: Color(0xFF8D6E63)),
        prefixIcon: Padding(
          padding: EdgeInsets.only(bottom: maxLines > 1 ? 40.0 : 0.0),
          child: Icon(icon, color: const Color(0xFF6D4C41)),
        ),
        alignLabelWithHint: true,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: Color(0xFFD7CCC8)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: Color(0xFFD7CCC8)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: Color(0xFF5D4037), width: 2),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: Colors.red, width: 1),
        ),
        filled: true,
        fillColor: Colors.white,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Color(0xFF3E2723),
            Color(0xFF4E342E),
            Color(0xFF5D4037),
          ],
        ),
      ),
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(
          title: Text(
            "New Expense",
            style: GoogleFonts.poppins(
              fontWeight: FontWeight.bold,
              color: const Color(0xFFFAF7F2),
            ),
          ),
          backgroundColor: Colors.transparent,
          elevation: 0,
          centerTitle: true,
          iconTheme: const IconThemeData(color: Color(0xFFFAF7F2)),
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: const Color(0xFFFAF7F2),
                borderRadius: BorderRadius.circular(24),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.2),
                    blurRadius: 15,
                    offset: const Offset(0, 5),
                  ),
                ],
              ),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const CircleAvatar(
                          radius: 22,
                          backgroundColor: Color(0xFFEFEBE9),
                          child: Icon(PhosphorIcons.receipt, color: Color(0xFF6D4C41), size: 24),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "Record Expenditure",
                                style: GoogleFonts.poppins(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: const Color(0xFF3E2723),
                                ),
                              ),
                              Text(
                                "Enter details for the new cafe expense",
                                style: GoogleFonts.poppins(
                                  fontSize: 12,
                                  color: const Color(0xFF8D6E63),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 25),
                    _buildTextField(
                      "Item Name",
                      _itemNameController,
                      PhosphorIcons.tag,
                      validator: (value) {
                        if (value == null || value.trim().isEmpty) {
                          return "Please enter an item name";
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 16),
                    _buildTextField(
                      "Price (Rs.)",
                      _priceController,
                      PhosphorIcons.currencyDollar,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      validator: (value) {
                        if (value == null || value.trim().isEmpty) {
                          return "Please enter a price";
                        }
                        final parsed = double.tryParse(value.trim());
                        if (parsed == null || parsed <= 0) {
                          return "Please enter a valid amount greater than 0";
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 16),
                    _buildTextField(
                      "Description (Optional)",
                      _descriptionController,
                      PhosphorIcons.notepad,
                      maxLines: 3,
                    ),
                    const SizedBox(height: 30),
                    SizedBox(
                      width: double.infinity,
                      height: 55,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF5D4037),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                          elevation: 0,
                        ),
                        onPressed: _isSubmitting ? null : _submitExpense,
                        child: _isSubmitting
                            ? const SizedBox(
                          width: 24,
                          height: 24,
                          child: CircularProgressIndicator(
                            color: Colors.white,
                            strokeWidth: 2,
                          ),
                        )
                            : Text(
                          "Save Expense",
                          style: GoogleFonts.poppins(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}