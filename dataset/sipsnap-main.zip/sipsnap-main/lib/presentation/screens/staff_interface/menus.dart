import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:google_fonts/google_fonts.dart';
import '../../../core/config/app_config.dart';

class MenuPage extends StatefulWidget {
  const MenuPage({super.key});

  @override
  State<MenuPage> createState() => _MenuPageState();
}

class _MenuPageState extends State<MenuPage> {
  final String apiUrl = '${AppConfig.baseUrl}/menu';
  final String categoryUrl = '${AppConfig.baseUrl}/category/all/cafe123456';

  List<dynamic> _allMenus = [];
  List<dynamic> _filteredMenus = [];
  List<dynamic> _categories = [];

  String _selectedCategoryId = 'all';
  String _searchQuery = '';
  bool _isLoadingCategories = true;

  @override
  void initState() {
    super.initState();
    _fetchCategories();
    _fetchMenus();
  }

  Future<void> _fetchCategories() async {
    try {
      final response = await http.get(Uri.parse(categoryUrl));
      if (response.statusCode == 200) {
        final decoded = json.decode(response.body);
        if (mounted) {
          setState(() {
            _categories = decoded['data'] ?? [];
            _isLoadingCategories = false;
          });
        }
      }
    } catch (e) {
      debugPrint("Category API Error: $e");
      if (mounted) setState(() => _isLoadingCategories = false);
    }
  }

  Future<void> _fetchMenus() async {
    try {
      final response = await http.get(Uri.parse(apiUrl));
      if (response.statusCode == 200) {
        final decoded = json.decode(response.body);
        if (mounted) {
          setState(() {
            _allMenus = decoded['data'] ?? [];
            _applyFilters();
          });
        }
      }
    } catch (e) {
      debugPrint("Menu API Error: $e");
    }
  }

  Future<void> _deleteMenu(String id) async {
    try {
      final response = await http.delete(Uri.parse('${AppConfig.baseUrl}/menu/delete/$id'));
      if (response.statusCode == 200) {
        _fetchMenus();
      }
    } catch (e) {
      debugPrint("Delete Error: $e");
    }
  }

  void _applyFilters() {
    setState(() {
      _filteredMenus = _allMenus.where((item) {
        final matchesSearch = item['name'].toString().toLowerCase().contains(_searchQuery.toLowerCase());

        bool matchesCategory = true;
        if (_selectedCategoryId != 'all') {
          final categoryField = item['category'];
          if (categoryField is Map) {
            matchesCategory = categoryField['_id'] == _selectedCategoryId;
          } else if (categoryField is String) {
            matchesCategory = categoryField == _selectedCategoryId;
          } else {
            matchesCategory = false;
          }
        }

        return matchesSearch && matchesCategory;
      }).toList();
    });
  }

  void _onSearchChanged(String query) {
    _searchQuery = query;
    _applyFilters();
  }

  void _onCategorySelected(String categoryId) {
    setState(() {
      _selectedCategoryId = categoryId;
    });
    _applyFilters();
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor, // Dynamically changes based on theme
      appBar: AppBar(
        title: Text("Menu Management", style: GoogleFonts.poppins(fontWeight: FontWeight.bold)),
        elevation: 0,
      ),
      body: Column(
        children: [
          // Search Bar
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: TextField(
              decoration: InputDecoration(
                hintText: "Search menu...",
                prefixIcon: const Icon(Icons.search),
                filled: true,
                fillColor: Theme.of(context).cardColor, // Dynamic card color for search input
                border: const OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(15)), borderSide: BorderSide.none),
              ),
              onChanged: _onSearchChanged,
            ),
          ),

          // Horizontal Category Filter Bar
          Container(
            height: 55,
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: _isLoadingCategories
                ? const Center(child: SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2)))
                : ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: [
                _buildFilterChip('all', 'All Items', isDarkMode),
                ..._categories.map((cat) => _buildFilterChip(cat['_id'], cat['name'], isDarkMode)),
              ],
            ),
          ),

          // Menu Grid View
          Expanded(
            child: _filteredMenus.isEmpty
                ? Center(
              child: Text("No menu items found", style: GoogleFonts.poppins(color: Colors.grey.shade600)),
            )
                : GridView.builder(
              padding: const EdgeInsets.all(16),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                  childAspectRatio: 0.75
              ),
              itemCount: _filteredMenus.length,
              itemBuilder: (context, index) => _buildMenuCard(_filteredMenus[index]),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterChip(String id, String label, bool isDarkMode) {
    bool isSelected = _selectedCategoryId == id;
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ChoiceChip(
        label: Text(label),
        selected: isSelected,
        selectedColor: Colors.indigo,
        backgroundColor: Theme.of(context).cardColor,
        labelStyle: GoogleFonts.poppins(
          color: isSelected ? Colors.white : (isDarkMode ? Colors.white70 : Colors.black87),
          fontWeight: FontWeight.w500,
          fontSize: 13,
        ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        onSelected: (_) => _onCategorySelected(id),
      ),
    );
  }

  Widget _buildMenuCard(dynamic item) {
    final String imageUrl = item['image']?['secureUrl'] ?? "";

    return Container(
      decoration: BoxDecoration(
          color: Theme.of(context).cardColor, // Adapts to light/dark card surface background
          borderRadius: BorderRadius.circular(20),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10)]
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: ClipRRect(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
              child: imageUrl.isNotEmpty
                  ? Image.network(imageUrl, fit: BoxFit.cover, width: double.infinity)
                  : Container(color: Colors.grey[200], child: const Center(child: Icon(Icons.fastfood, color: Colors.grey))),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(child: Text(item['name'], style: GoogleFonts.poppins(fontWeight: FontWeight.bold), overflow: TextOverflow.ellipsis)),
                    PopupMenuButton<String>(
                      padding: EdgeInsets.zero,
                      itemBuilder: (context) => [
                        const PopupMenuItem(value: 'edit', child: Text("Edit")),
                        const PopupMenuItem(value: 'delete', child: Text("Delete")),
                      ],
                      onSelected: (val) {
                        if (val == 'delete') _deleteMenu(item['_id']);
                        else debugPrint("Navigate to Edit");
                      },
                    )
                  ],
                ),
                Text(
                  "Rs. ${item['price']}",
                  style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.green,
                      fontSize: 14
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}