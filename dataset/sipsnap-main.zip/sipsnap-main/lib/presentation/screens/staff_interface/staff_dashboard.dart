import 'package:flutter/material.dart';
import 'package:animate_do/animate_do.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../../../providers/auth_provider.dart';
// Import your theme provider (adjust the relative path if needed)
import '../../../providers/theme_provider.dart';
import '../category/categoryPage.dart';
import './table.dart';
import './menus.dart';
import './../order/tableSelection.dart';
import './../order/OrderListPage.dart';
import './login.dart';
import './../expense/viewAllTheExpenses.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final authProvider = context.watch<AuthProvider>();
    final user = authProvider.user;

    debugPrint("Logged in user: ${user?.name}");

    final String userName = user?.name ?? "User";
    final String cafeName = user?.cafeName ?? "EGCafe";
    final String cafeUserName = user?.cafeUserName ?? "cafe123456";
    final String role = user?.role ?? "user";

    final bool isLoading = user == null;
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            children: [
              _buildHeader(context, cafeName, userName, role, isDarkMode),
              const SizedBox(height: 30),
              _buildGreeting(userName, isLoading, isDarkMode),
              const SizedBox(height: 25),
              Expanded(
                child: Scrollbar(
                  child: _buildDashboardGrid(context, cafeUserName, isDarkMode),
                ),
              ),
              const SizedBox(height: 100),
            ],
          ),
        ),
      ),
      bottomSheet: _buildFloatingActionButton(),
    );
  }

  Widget _buildHeader(BuildContext context, String cafeName, String userName, String role, bool isDarkMode) {
    // Watch the ThemeProvider to handle theme toggling states
    final themeProvider = context.watch<ThemeProvider>();

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(children: [
          CircleAvatar(
            backgroundColor: Colors.indigo,
            child: Text(
              cafeName.isNotEmpty ? cafeName[0].toUpperCase() : "C",
              style: const TextStyle(color: Colors.white),
            ),
          ),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                cafeName,
                style: GoogleFonts.poppins(
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                  color: isDarkMode ? Colors.white : Colors.black87,
                ),
              ),
              Text(
                role.toUpperCase(),
                style: GoogleFonts.poppins(
                  fontSize: 10,
                  color: isDarkMode ? Colors.white70 : Colors.grey.shade600,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ]),
        Row(
          children: [
            // Dark Mode Toggle Button using ThemeProvider
            Container(
              margin: const EdgeInsets.only(right: 10),
              decoration: BoxDecoration(
                color: Theme.of(context).cardColor,
                borderRadius: BorderRadius.circular(30),
                boxShadow: [
                  BoxShadow(
                    blurRadius: 10,
                    color: Colors.black.withOpacity(isDarkMode ? 0.2 : 0.08),
                  ),
                ],
              ),
              child: IconButton(
                icon: Icon(
                  themeProvider.isDarkMode ? PhosphorIcons.sun : PhosphorIcons.moon,
                  size: 20,
                  color: themeProvider.isDarkMode ? Colors.amber : Colors.indigo,
                ),
                onPressed: () {
                  themeProvider.toggleTheme();
                },
                tooltip: themeProvider.isDarkMode ? "Switch to Light Mode" : "Switch to Dark Mode",
              ),
            ),
            // Profile & Settings Popup Menu
            PopupMenuButton<String>(
              offset: const Offset(0, 45),
              color: Theme.of(context).cardColor,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              elevation: 4,
              onSelected: (value) async {
                if (value == 'profile') {
                  debugPrint("Navigate to Profile");
                } else if (value == 'settings') {
                  debugPrint("Navigate to Settings");
                } else if (value == 'logout') {
                  context.read<AuthProvider>().logout();

                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => const StaffLoginScreen()),
                  );
                }
              },
              itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
                PopupMenuItem<String>(
                  value: 'profile',
                  child: Row(
                    children: [
                      const Icon(PhosphorIcons.user, size: 20, color: Colors.indigoAccent),
                      const SizedBox(width: 12),
                      Text("Profile", style: GoogleFonts.poppins(fontWeight: FontWeight.w500, color: isDarkMode ? Colors.white : Colors.black87)),
                    ],
                  ),
                ),
                PopupMenuItem<String>(
                  value: 'settings',
                  child: Row(
                    children: [
                      const Icon(PhosphorIcons.gear, size: 20, color: Colors.indigoAccent),
                      const SizedBox(width: 12),
                      Text("Settings", style: GoogleFonts.poppins(fontWeight: FontWeight.w500, color: isDarkMode ? Colors.white : Colors.black87)),
                    ],
                  ),
                ),
                const PopupMenuDivider(),
                PopupMenuItem<String>(
                  value: 'logout',
                  child: Row(
                    children: [
                      const Icon(PhosphorIcons.signOut, size: 20, color: Colors.redAccent),
                      const SizedBox(width: 12),
                      Text("Logout", style: GoogleFonts.poppins(fontWeight: FontWeight.w500, color: Colors.redAccent)),
                    ],
                  ),
                ),
              ],
              child: Container(
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  color: Theme.of(context).cardColor,
                  borderRadius: BorderRadius.circular(30),
                  boxShadow: [
                    BoxShadow(
                      blurRadius: 10,
                      color: Colors.black.withOpacity(isDarkMode ? 0.2 : 0.12),
                    ),
                  ],
                ),
                child: Row(children: [
                  CircleAvatar(
                    radius: 15,
                    backgroundColor: isDarkMode ? Colors.indigo.shade900.withOpacity(0.5) : Colors.indigo.shade100,
                    child: Text(
                      userName.isNotEmpty ? userName[0].toUpperCase() : "U",
                      style: GoogleFonts.poppins(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.indigoAccent),
                    ),
                  ),
                  const SizedBox(width: 5),
                  Icon(PhosphorIcons.caretDown, size: 16, color: isDarkMode ? Colors.white70 : Colors.black87)
                ]),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildGreeting(String userName, bool isLoading, bool isDarkMode) {
    final formattedDate = DateFormat('EEEE, d MMMM yyyy').format(DateTime.now());

    return FadeInDown(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(
          isLoading ? "Loading..." : "Good Evening, $userName 👋",
          style: GoogleFonts.poppins(
            fontSize: 24,
            fontWeight: FontWeight.w600,
            color: isDarkMode ? Colors.white : Colors.black87,
          ),
        ),
        Text(formattedDate, style: TextStyle(color: isDarkMode ? Colors.white60 : Colors.grey.shade600)),
      ]),
    );
  }

  Widget _buildDashboardGrid(BuildContext context, String cafeUserName, bool isDarkMode) {
    final modules = [
      {'title': 'Menu', 'icon': PhosphorIcons.hamburger, 'color': Colors.orange},
      {'title': 'Tables', 'icon': PhosphorIcons.table, 'color': Colors.cyan},
      {'title': 'Orders', 'icon': PhosphorIcons.package, 'color': Colors.blue},
      {'title': 'Categories', 'icon': PhosphorIcons.listBullets, 'color': Colors.teal},
      {'title': 'Expenses', 'icon': PhosphorIcons.trendDown, 'color': Colors.redAccent},
    ];

    return GridView.builder(
      padding: const EdgeInsets.only(bottom: 20),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 15, mainAxisSpacing: 15),
      itemCount: modules.length,
      itemBuilder: (context, index) => BounceInDown(
        delay: Duration(milliseconds: index * 50),
        child: InkWell(
          borderRadius: BorderRadius.circular(24),
          onTap: () {
            final title = modules[index]['title'] as String;
            switch (title) {
              case 'Tables':
                Navigator.push(context, MaterialPageRoute(builder: (context) => const TablePage()));
                break;
              case 'Menu':
                Navigator.push(context, MaterialPageRoute(builder: (context) => const MenuPage()));
                break;
              case 'Categories':
                Navigator.push(context, MaterialPageRoute(builder: (context) => CategoryPage(cafeUserName: cafeUserName)));
                break;
              case 'Expenses':
                Navigator.push(context, MaterialPageRoute(builder: (context) => ExpensePage(cafeUserName: cafeUserName)));
                break;
              case 'Orders':
                Navigator.push(context, MaterialPageRoute(builder: (context) => const OrderListPage()));
                break;
              default:
                debugPrint("Tapped on $title");
            }
          },
          child: Container(
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              borderRadius: BorderRadius.circular(24),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(isDarkMode ? 0.2 : 0.05),
                  blurRadius: 15,
                ),
              ],
            ),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(modules[index]['icon'] as IconData, size: 40, color: modules[index]['color'] as Color),
              const SizedBox(height: 10),
              Text(
                modules[index]['title'] as String,
                style: GoogleFonts.poppins(
                  fontWeight: FontWeight.w600,
                  color: isDarkMode ? Colors.white : Colors.black87,
                ),
              ),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _buildFloatingActionButton() {
    return Builder(
      builder: (context) {
        return Container(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(30),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const TableSelectionPage()),
              );
            },
            child: Container(
              height: 70,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF4E342E), Color(0xFF3E2723), Color(0xFF2D1B18)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(30),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF3E2723).withOpacity(0.45),
                    blurRadius: 20,
                    offset: const Offset(0, 10),
                  ),
                ],
                border: Border.all(
                  color: Colors.brown.shade300.withOpacity(0.3),
                  width: 1.5,
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.15),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.add, color: Colors.white, size: 22),
                  ),
                  const SizedBox(width: 12),
                  Text(
                    "Create New Order",
                    style: GoogleFonts.poppins(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 0.5,
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}