import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:animate_do/animate_do.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';
import '../../../providers/auth_provider.dart';
import '../../../core/config/app_config.dart';

class TablePage extends StatefulWidget {
  final String? cafeUserName;

  const TablePage({
    super.key,
    this.cafeUserName,
  });

  @override
  State<TablePage> createState() => _TablePageState();
}

class _TablePageState extends State<TablePage> {
  List<dynamic> _allTables = [];
  List<dynamic> _filteredTables = [];
  bool _isLoading = true;
  String _searchQuery = "";
  String _statusFilter = "All";

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _fetchTables();
    });
  }

  String _resolveCafeUserName() {
    if (widget.cafeUserName != null && widget.cafeUserName!.isNotEmpty) {
      return widget.cafeUserName!;
    }
    final authProvider = context.read<AuthProvider>();

    final resolved = authProvider.user?['cafeUserName'] ?? "";
    return resolved;
  }

  Future<String?> _resolveAccessToken() async {
    final authProvider = context.read<AuthProvider>();
    return authProvider.accessToken;
  }

  Future<void> _fetchTables() async {
    final cafeUserName = _resolveCafeUserName();
    final accessToken = await _resolveAccessToken();

    if (cafeUserName.isEmpty) {
      if (mounted) setState(() => _isLoading = false);
      return;
    }

    try {
      final apiUrl = '${AppConfig.baseUrl}/api/v1/table/$cafeUserName';
      final response = await http.get(
        Uri.parse(apiUrl),
        headers: {
          'Content-Type': 'application/json',
          if (accessToken != null && accessToken.isNotEmpty)
            'Authorization': 'Bearer $accessToken',
        },
      );

      if (response.statusCode == 200) {
        final decoded = json.decode(response.body);
        final data = decoded['data'] ?? [];
        if (mounted) {
          setState(() {
            _allTables = data;
            _applyFilters();
            _isLoading = false;
          });
        }
      } else {
        if (mounted) setState(() => _isLoading = false);
      }
    } catch (e) {
      debugPrint("Error fetching tables: $e");
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _createTable({required String tableName, required int capacity}) async {
    final accessToken = await _resolveAccessToken();
    final cafeUserName = _resolveCafeUserName();

    if (cafeUserName.isEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Error: Cafe username context is missing.")),
        );
      }
      return;
    }

    try {
      final url = Uri.parse('${AppConfig.baseUrl}/api/v1/table');
      final Map<String, dynamic> requestBody = {
        "name": tableName,
        "capacity": capacity,
        "cafeUserName": cafeUserName,
        "status": "Available",
      };

      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
          if (accessToken != null && accessToken.isNotEmpty)
            'Authorization': 'Bearer $accessToken',
        },
        body: jsonEncode(requestBody),
      );

      final decoded = jsonDecode(response.body);

      if (response.statusCode == 201 || response.statusCode == 200) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(decoded['message'] ?? "Table added successfully")),
          );
          _fetchTables();
        }
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(decoded['message'] ?? "Failed to add table")),
          );
        }
      }
    } catch (e) {
      debugPrint("Error creating table: $e");
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Network error while creating table")),
        );
      }
    }
  }

  void _applyFilters() {
    setState(() {
      _filteredTables = _allTables.where((table) {
        final matchesSearch = table['name'].toString().toLowerCase().contains(_searchQuery.toLowerCase());
        final matchesStatus = _statusFilter == "All" || table['status']?.toString().toLowerCase() == _statusFilter.toLowerCase();
        return matchesSearch && matchesStatus;
      }).toList();
    });
  }

  Color _getStatusColor(String? status) {
    switch (status?.toLowerCase()) {
      case 'available':
        return Colors.green;
      case 'occupied':
        return Colors.red;
      case 'reserved':
        return Colors.amber;
      case 'cleaning':
        return Colors.blue;
      default:
        return Colors.grey;
    }
  }

  void _showAddTableModal(bool isDarkMode) {
    final nameController = TextEditingController();
    final capacityController = TextEditingController();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(context).viewInsets.bottom,
          left: 20,
          right: 20,
          top: 25,
        ),
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(30)),
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade600,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Text(
                "Add New Table",
                style: GoogleFonts.poppins(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: isDarkMode ? Colors.white : Colors.black87,
                ),
              ),
              const SizedBox(height: 20),
              TextField(
                controller: nameController,
                style: TextStyle(color: isDarkMode ? Colors.white : Colors.black87),
                decoration: InputDecoration(
                  labelText: "Table Name / Number",
                  labelStyle: TextStyle(color: isDarkMode ? Colors.white70 : Colors.black54),
                  prefixIcon: const Icon(PhosphorIcons.table, color: Colors.indigo),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                  filled: true,
                  fillColor: isDarkMode ? Colors.grey.shade900 : const Color(0xFFF8F9FE),
                ),
              ),
              const SizedBox(height: 15),
              TextField(
                controller: capacityController,
                keyboardType: TextInputType.number,
                style: TextStyle(color: isDarkMode ? Colors.white : Colors.black87),
                decoration: InputDecoration(
                  labelText: "Capacity (e.g. 4)",
                  labelStyle: TextStyle(color: isDarkMode ? Colors.white70 : Colors.black54),
                  prefixIcon: const Icon(PhosphorIcons.users, color: Colors.indigo),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                  filled: true,
                  fillColor: isDarkMode ? Colors.grey.shade900 : const Color(0xFFF8F9FE),
                ),
              ),
              const SizedBox(height: 30),
              SizedBox(
                width: double.infinity,
                height: 55,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF6366F1),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    elevation: 0,
                  ),
                  onPressed: () async {
                    final name = nameController.text.trim();
                    final capacity = int.tryParse(capacityController.text.trim()) ?? 4;
                    if (name.isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text("Please provide a valid table name")),
                      );
                      return;
                    }

                    Navigator.pop(context);
                    await _createTable(tableName: name, capacity: capacity);
                  },
                  child: Text(
                    "Save Table",
                    style: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.w600, color: Colors.white),
                  ),
                ),
              ),
              const SizedBox(height: 30),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text(
          "Manage Tables",
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.bold,
            color: isDarkMode ? Colors.white : Colors.black87,
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        iconTheme: IconThemeData(color: isDarkMode ? Colors.white : Colors.black87),
      ),
      body: Column(
        children: [
          _buildLegend(isDarkMode),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            child: Row(
              children: [
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      color: Theme.of(context).cardColor,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(isDarkMode ? 0.2 : 0.04),
                          blurRadius: 10,
                        ),
                      ],
                    ),
                    child: TextField(
                      style: TextStyle(color: isDarkMode ? Colors.white : Colors.black87),
                      decoration: InputDecoration(
                        hintText: "Search tables...",
                        hintStyle: TextStyle(color: isDarkMode ? Colors.white60 : Colors.grey.shade400, fontSize: 14),
                        prefixIcon: const Icon(PhosphorIcons.magnifyingGlass, color: Colors.indigo),
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
                      ),
                      onChanged: (v) {
                        _searchQuery = v;
                        _applyFilters();
                      },
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  decoration: BoxDecoration(
                    color: Theme.of(context).cardColor,
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(isDarkMode ? 0.2 : 0.04),
                        blurRadius: 10,
                      ),
                    ],
                  ),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<String>(
                      value: _statusFilter,
                      dropdownColor: Theme.of(context).cardColor,
                      style: TextStyle(color: isDarkMode ? Colors.white : Colors.black87, fontSize: 14),
                      items: ["All", "Available", "Occupied", "Reserved", "Cleaning"]
                          .map((s) => DropdownMenuItem(
                        value: s,
                        child: Text(s, style: TextStyle(color: isDarkMode ? Colors.white : Colors.black87)),
                      ))
                          .toList(),
                      onChanged: (v) {
                        if (v != null) {
                          setState(() {
                            _statusFilter = v;
                            _applyFilters();
                          });
                        }
                      },
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Container(
                  height: 52,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [Color(0xFF6366F1), Color(0xFFA855F7)]),
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [BoxShadow(color: Colors.indigo.withOpacity(0.3), blurRadius: 10, offset: const Offset(0, 4))],
                  ),
                  child: IconButton(
                    icon: const Icon(Icons.add, color: Colors.white, size: 26),
                    onPressed: () => _showAddTableModal(isDarkMode),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator(color: Colors.indigo))
                : _filteredTables.isEmpty
                ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(PhosphorIcons.table, size: 60, color: isDarkMode ? Colors.white60 : Colors.grey.shade400),
                  const SizedBox(height: 10),
                  Text(
                    "No tables found",
                    style: GoogleFonts.poppins(color: isDarkMode ? Colors.white60 : Colors.grey.shade500, fontSize: 16),
                  ),
                ],
              ),
            )
                : GridView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 16,
                mainAxisSpacing: 16,
                childAspectRatio: 1.1,
              ),
              itemCount: _filteredTables.length,
              itemBuilder: (context, index) {
                return FadeInUp(
                  delay: Duration(milliseconds: index * 50),
                  child: _buildTableCard(_filteredTables[index], isDarkMode),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLegend(bool isDarkMode) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
      child: Row(
        children: [
          {"color": Colors.green, "text": "Available"},
          {"color": Colors.red, "text": "Occupied"},
          {"color": Colors.amber, "text": "Reserved"},
          {"color": Colors.blue, "text": "Cleaning"}
        ]
            .map((l) => Padding(
          padding: const EdgeInsets.only(right: 15),
          child: Row(
            children: [
              CircleAvatar(radius: 6, backgroundColor: l['color'] as Color),
              const SizedBox(width: 5),
              Text(
                l['text'] as String,
                style: TextStyle(
                  fontSize: 12,
                  color: isDarkMode ? Colors.white70 : Colors.black87,
                ),
              ),
            ],
          ),
        ))
            .toList(),
      ),
    );
  }

  Widget _buildTableCard(dynamic table, bool isDarkMode) {
    final status = table['status'] ?? 'unknown';
    Color statusColor = _getStatusColor(status);

    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: statusColor, width: 2),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(isDarkMode ? 0.2 : 0.04),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Stack(
        children: [
          Align(
            alignment: Alignment.topRight,
            child: PopupMenuButton<String>(
              color: Theme.of(context).cardColor,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              onSelected: (val) => debugPrint(val),
              itemBuilder: (ctx) => [
                PopupMenuItem(
                  value: 'edit',
                  child: Text('Edit', style: TextStyle(color: isDarkMode ? Colors.white : Colors.black87)),
                ),
                PopupMenuItem(
                  value: 'delete',
                  child: Text('Delete', style: TextStyle(color: isDarkMode ? Colors.white : Colors.black87)),
                ),
              ],
            ),
          ),
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(PhosphorIcons.table, size: 32, color: statusColor),
                const SizedBox(height: 8),
                Text(
                  table['name'] ?? 'Table',
                  style: GoogleFonts.poppins(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                    color: isDarkMode ? Colors.white : Colors.black87,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  status.toUpperCase(),
                  style: TextStyle(
                    color: statusColor,
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}