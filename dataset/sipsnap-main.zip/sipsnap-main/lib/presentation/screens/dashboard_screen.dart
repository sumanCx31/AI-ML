import 'package:flutter/material.dart';
import 'package:animate_do/animate_do.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../providers/auth_provider.dart';
import '../../providers/theme_provider.dart';
import 'category/categoryPage.dart';
import './table.dart';
import './menus/menus.dart';
import './order/tableSelection.dart';
import './stats/analyttics.dart';
import './order/OrderListPage.dart';
import './staff/listStaffPage.dart';
import './login_screen.dart';
import './expense/viewAllTheExpenses.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Watch the auth provider so the screen reacts to global state updates
    final authProvider = context.watch<AuthProvider>();
    final user = authProvider.user;
    // debugPrint('RESPONSE FROM GLOBAL PROVIDER:${user?.cafeName}');

    // 1. Role-based access control check
    if (user != null && user.role.toLowerCase() == 'staff') {
      // Use addPostFrameCallback to avoid navigation during build phase
      WidgetsBinding.instance.addPostFrameCallback((_) {
        authProvider.logout(); // Clear token state
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const LoginScreen()),
        );

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              "Staff members do not have access to the admin dashboard.",
              style: GoogleFonts.poppins(fontWeight: FontWeight.w500),
            ),
            backgroundColor: Colors.red.shade600,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
        );
      });

      // Return an empty container while redirecting
      return const Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    // Fallback data if user model is still loading
    final String userName = user?.name ?? "User";
    final String cafeName = user?.cafeName ?? "EGCafe";
    final String cafeUserName = user?.cafeUserName ?? "cafe123456";
    final String? imageUrl = user?.image.optimizedUrl;

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            children: [
              _buildHeader(context, cafeName, imageUrl),
              const SizedBox(height: 30),
              _buildGreeting(userName, user == null),
              const SizedBox(height: 25),
              Expanded(
                child: Scrollbar(
                  child: _buildDashboardGrid(context, cafeUserName),
                ),
              ),
              const SizedBox(height: 100),
            ],
          ),
        ),
      ),
      bottomSheet: _buildFloatingActionButton(context),
    );
  }

  Widget _buildHeader(BuildContext context, String cafeName, String? imageUrl) {
    final themeProvider = context.watch<ThemeProvider>();
    final isDarkMode = themeProvider.isDarkMode;

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            CircleAvatar(
              backgroundColor: Colors.indigo,
              child: Text(
                cafeName.isNotEmpty ? cafeName[0].toUpperCase() : "C",
                style: const TextStyle(color: Colors.white),
              ),
            ),
            const SizedBox(width: 10),
            Text(
              cafeName,
              style: GoogleFonts.poppins(
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),
          ],
        ),
        PopupMenuButton<String>(
          offset: const Offset(0, 45),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          elevation: 4,
          onSelected: (value) {
            if (value == 'profile') {
              debugPrint("Navigate to Profile");
            } else if (value == 'settings') {
              context.read<ThemeProvider>().toggleTheme();
            } else if (value == 'logout') {
              context.read<AuthProvider>().logout();
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => const LoginScreen()),
              );
            }
          },
          itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
            PopupMenuItem<String>(
              value: 'profile',
              child: Row(
                children: [
                  const Icon(PhosphorIcons.user, size: 20, color: Colors.indigo),
                  const SizedBox(width: 12),
                  Text("Profile", style: GoogleFonts.poppins(fontWeight: FontWeight.w500)),
                ],
              ),
            ),
            PopupMenuItem<String>(
              value: 'settings',
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Icon(
                        isDarkMode ? PhosphorIcons.moon : PhosphorIcons.sun,
                        size: 20,
                        color: Colors.indigo,
                      ),
                      const SizedBox(width: 12),
                      Text("Dark Mode", style: GoogleFonts.poppins(fontWeight: FontWeight.w500)),
                    ],
                  ),
                  Switch.adaptive(
                    value: isDarkMode,
                    onChanged: (val) {
                      context.read<ThemeProvider>().toggleTheme();
                      Navigator.pop(context); // Close dropdown menu after toggling
                    },
                  ),
                ],
              ),
            ),
            const PopupMenuDivider(),
            PopupMenuItem<String>(
              value: 'logout',
              child: Row(
                children: [
                  const Icon(PhosphorIcons.signOut, size: 20, color: Colors.redAccent),
                  const SizedBox(width: 12),
                  Text(
                    "Logout",
                    style: GoogleFonts.poppins(
                      fontWeight: FontWeight.w500,
                      color: Colors.redAccent,
                    ),
                  ),
                ],
              ),
            ),
          ],
          child: Container(
            padding: const EdgeInsets.all(4),
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              borderRadius: BorderRadius.circular(30),
              boxShadow: const [BoxShadow(blurRadius: 10, color: Colors.black12)],
            ),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 15,
                  backgroundColor: Colors.grey.shade300,
                  backgroundImage: (imageUrl != null && imageUrl.isNotEmpty)
                      ? NetworkImage(imageUrl)
                      : null,
                  child: (imageUrl == null || imageUrl.isEmpty)
                      ? const Icon(Icons.person, size: 16, color: Colors.grey)
                      : null,
                ),
                const SizedBox(width: 5),
                const Icon(PhosphorIcons.caretDown, size: 16),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildGreeting(String userName, bool isLoading) {
    final formattedDate = DateFormat('EEEE, d MMMM yyyy').format(DateTime.now());

    return FadeInDown(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            isLoading ? "Loading..." : "Good Afternoon, $userName 👋",
            style: GoogleFonts.poppins(fontSize: 24, fontWeight: FontWeight.w600),
          ),
          Text(formattedDate, style: TextStyle(color: Colors.grey.shade600)),
        ],
      ),
    );
  }

  Widget _buildDashboardGrid(BuildContext context, String cafeUserName) {
    final modules = [
      {'title': 'Menu', 'icon': PhosphorIcons.hamburger, 'color': Colors.orange},
      {'title': 'Tables', 'icon': PhosphorIcons.table, 'color': Colors.cyan},
      {'title': 'Orders', 'icon': PhosphorIcons.package, 'color': Colors.blue},
      {'title': 'Stats', 'icon': PhosphorIcons.chartBar, 'color': Colors.blue},
      {'title': 'Categories', 'icon': PhosphorIcons.listBullets, 'color': Colors.teal},
      {'title': 'Members', 'icon': PhosphorIcons.users, 'color': Colors.purple},
      {'title': 'Revenue', 'icon': PhosphorIcons.currencyDollar, 'color': Colors.green},
      {'title': 'Payments', 'icon': PhosphorIcons.creditCard, 'color': Colors.pink},
      {'title': 'Customers', 'icon': PhosphorIcons.userList, 'color': Colors.indigo},
      {'title': 'Expenses', 'icon': PhosphorIcons.trendDown, 'color': Colors.redAccent},
    ];

    return GridView.builder(
      padding: const EdgeInsets.only(bottom: 20),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 15,
        mainAxisSpacing: 15,
      ),
      itemCount: modules.length,
      itemBuilder: (context, index) => BounceInDown(
        delay: Duration(milliseconds: index * 50),
        child: InkWell(
          borderRadius: BorderRadius.circular(24),
          onTap: () {
            final title = modules[index]['title'] as String;
            switch (title) {
              case 'Tables':
                Navigator.push(context, MaterialPageRoute(builder: (context) => const TablePage()));
                break;
              case 'Menu':
                Navigator.push(context, MaterialPageRoute(builder: (context) => const MenuPage()));
                break;
              case 'Categories':
                Navigator.push(context, MaterialPageRoute(builder: (context) => CategoryPage(cafeUserName: cafeUserName)));
                break;
              case 'Expenses':
                Navigator.push(context, MaterialPageRoute(builder: (context) => ExpensePage(cafeUserName: cafeUserName)));
                break;
              case 'Members':
                Navigator.push(context, MaterialPageRoute(builder: (context) => ListStaffPage(cafeUserName: cafeUserName)));
                break;
              case 'Stats':
                Navigator.push(context, MaterialPageRoute(builder: (context) => AnalyticsDashboard(cafeUserName: cafeUserName)));
                break;
              case 'Orders':
                Navigator.push(context, MaterialPageRoute(builder: (context) => const OrderListPage()));
                break;
              default:
                debugPrint("Tapped on $title");
            }
          },
          child: Container(
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              borderRadius: BorderRadius.circular(24),
              boxShadow: [
                BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 15)
              ],
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  modules[index]['icon'] as IconData,
                  size: 40,
                  color: modules[index]['color'] as Color,
                ),
                const SizedBox(height: 10),
                Text(
                  modules[index]['title'] as String,
                  style: GoogleFonts.poppins(fontWeight: FontWeight.w600),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildFloatingActionButton(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(30),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const TableSelectionPage()),
          );
        },
        child: Container(
          height: 70,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF6366F1), Color(0xFFA855F7)],
            ),
            borderRadius: BorderRadius.circular(30),
            boxShadow: [
              BoxShadow(
                color: Colors.indigo.withOpacity(0.4),
                blurRadius: 20,
                offset: const Offset(0, 10),
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.add, color: Colors.white, size: 30),
              const SizedBox(width: 10),
              Text(
                "Create New Order",
                style: GoogleFonts.poppins(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}