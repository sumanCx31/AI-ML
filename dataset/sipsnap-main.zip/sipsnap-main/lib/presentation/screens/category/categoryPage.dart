import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:image_picker/image_picker.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:provider/provider.dart';
import 'package:egcafe/providers/auth_provider.dart';
import 'package:egcafe/providers/staff_auth_provider.dart';
import '../../../core/config/app_config.dart';
import '../../widgets/sipsnap_loading_logo.dar.dart';

class CategoryPage extends StatefulWidget {
  final String cafeUserName;
  const CategoryPage({super.key, required this.cafeUserName});

  @override
  _CategoryPageState createState() => _CategoryPageState();
}

class _CategoryPageState extends State<CategoryPage> {
  List<dynamic> categories = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchCategories();
  }

  Future<String?> _resolveAccessToken() async {
    final staffAuthProvider = context.read<StaffAuthProvider>();
    final authProvider = context.read<AuthProvider>();
    return staffAuthProvider.staffDetails != null ? null : authProvider.accessToken;
  }

  Future<String> _resolveCafeUserName() async {
    if (widget.cafeUserName.isNotEmpty) return widget.cafeUserName;
    final staffAuthProvider = context.read<StaffAuthProvider>();
    final authProvider = context.read<AuthProvider>();
    return staffAuthProvider.staffDetails?['cafeUserName'] ??
        authProvider.user?.cafeUserName ??
        "cafe123456";
  }

  Future<void> _fetchCategories() async {
    try {
      final cafeUserName = await _resolveCafeUserName();
      final String? accessToken = await _resolveAccessToken();

      final res = await http.get(
        Uri.parse('${AppConfig.baseUrl}/category/all/$cafeUserName'),
        headers: {
          "Content-Type": "application/json",
          if (accessToken != null) 'Authorization': 'Bearer $accessToken',
        },
      );

      if (res.statusCode == 200) {
        setState(() => categories = jsonDecode(res.body)['data'] ?? []);
      }
    } catch (e) {
      debugPrint("Error fetching categories: $e");
    } finally {
      if (mounted) setState(() => isLoading = false);
    }
  }

  Future<void> _deleteCategory(String categoryId) async {
    try {
      final String? accessToken = await _resolveAccessToken();

      final res = await http.delete(
        Uri.parse('${AppConfig.baseUrl}/category/delete/$categoryId'),
        headers: {
          "Content-Type": "application/json",
          if (accessToken != null) 'Authorization': 'Bearer $accessToken',
        },
      );

      if (res.statusCode == 200 || res.statusCode == 204) {
        setState(() {
          categories.removeWhere((cat) => cat['_id'] == categoryId);
        });
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("Category deleted successfully")),
          );
        }
      } else {
        final decoded = jsonDecode(res.body);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(decoded['message'] ?? "Failed to delete category")),
          );
        }
      }
    } catch (e) {
      debugPrint("Delete Category Error: $e");
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("An error occurred while deleting")),
        );
      }
    }
  }

  void _confirmDelete(String categoryId, String categoryName) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Theme.of(context).cardColor,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(
          "Delete Category",
          style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
        ),
        content: Text(
          "Are you sure you want to delete '$categoryName'?",
          style: GoogleFonts.poppins(),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Cancel", style: GoogleFonts.poppins(color: Colors.grey)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            ),
            onPressed: () {
              Navigator.pop(context);
              _deleteCategory(categoryId);
            },
            child: Text("Delete", style: GoogleFonts.poppins(color: Colors.white, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text(
          "Categories",
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.bold,
            color: isDarkMode ? Colors.white : Colors.black87,
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: IconThemeData(color: isDarkMode ? Colors.white : Colors.black87),
        actions: [
          IconButton(
            icon: Icon(PhosphorIcons.plusCircleBold, color: isDarkMode ? Colors.white : Colors.black87),
            onPressed: () => _showCreateCategoryDialog(),
          )
        ],
      ),
      body: isLoading
          ? const Center(child: SipSnapAnimatedLogo(fontSize: 22))
          : categories.isEmpty
          ? Center(
        child: Text(
          "No categories found",
          style: GoogleFonts.poppins(color: Colors.grey.shade500, fontSize: 14),
        ),
      )
          : GridView.builder(
        padding: const EdgeInsets.all(16),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 16,
          mainAxisSpacing: 16,
          childAspectRatio: 0.85,
        ),
        itemCount: categories.length,
        itemBuilder: (_, i) => _buildCategoryCard(categories[i], isDarkMode),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showCreateCategoryDialog(),
        backgroundColor: Colors.indigo,
        label: Text("Add Category", style: GoogleFonts.poppins(fontWeight: FontWeight.w600, color: Colors.white)),
        icon: const Icon(Icons.add, color: Colors.white),
      ),
    );
  }

  Widget _buildCategoryCard(dynamic cat, bool isDarkMode) {
    final categoryId = cat['_id'] ?? '';
    final categoryName = cat['name'] ?? '';

    return Stack(
      children: [
        Container(
          decoration: BoxDecoration(
            color: Theme.of(context).cardColor,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(isDarkMode ? 0.2 : 0.05),
                blurRadius: 10,
                offset: const Offset(0, 5),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: ClipRRect(
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
                  child: Image.network(
                    cat['image']?['optimizedUrl'] ?? '',
                    width: double.infinity,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(
                      color: isDarkMode ? Colors.grey.shade900 : Colors.grey.shade200,
                      child: const Icon(Icons.image_not_supported, color: Colors.grey),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      categoryName,
                      style: GoogleFonts.poppins(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        color: isDarkMode ? Colors.white : Colors.black87,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      cat['description'] ?? '',
                      style: GoogleFonts.poppins(
                        fontSize: 12,
                        color: isDarkMode ? Colors.white70 : Colors.grey.shade600,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
        // Delete Action Button Overlaid on Top Right of Card
        Positioned(
          top: 8,
          right: 8,
          child: CircleAvatar(
            backgroundColor: Colors.black54,
            radius: 16,
            child: IconButton(
              padding: EdgeInsets.zero,
              icon: const Icon(Icons.delete_outline, size: 16, color: Colors.white),
              onPressed: () => _confirmDelete(categoryId, categoryName),
            ),
          ),
        ),
      ],
    );
  }

  void _showCreateCategoryDialog() {
    final formKey = GlobalKey<FormState>();
    final nameController = TextEditingController();
    final descController = TextEditingController();
    File? selectedImage;
    bool isSubmitting = false;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Theme.of(context).cardColor,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
      ),
      builder: (context) => StatefulBuilder(
        builder: (context, setModalState) {
          final isDarkMode = Theme.of(context).brightness == Brightness.dark;

          Future<void> pickImage() async {
            try {
              final pickedFile = await ImagePicker().pickImage(source: ImageSource.gallery);
              if (pickedFile != null) {
                setModalState(() => selectedImage = File(pickedFile.path));
              }
            } catch (e) {
              debugPrint("Image Picker Error: $e");
            }
          }

          return Padding(
            padding: EdgeInsets.only(
              bottom: MediaQuery.of(context).viewInsets.bottom,
              left: 20,
              right: 20,
              top: 25,
            ),
            child: SingleChildScrollView(
              child: Form(
                key: formKey,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(
                      "Create Category",
                      style: GoogleFonts.poppins(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: isDarkMode ? Colors.white : Colors.black87,
                      ),
                    ),
                    const SizedBox(height: 20),

                    // Optional Image Picker Box
                    GestureDetector(
                      onTap: pickImage,
                      child: Container(
                        height: 120,
                        decoration: BoxDecoration(
                          color: isDarkMode ? Colors.grey.shade900 : Colors.grey.shade100,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: isDarkMode ? Colors.grey.shade800 : Colors.grey.shade300,
                          ),
                        ),
                        child: selectedImage != null
                            ? Stack(
                          fit: StackFit.expand,
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(12),
                              child: Image.file(selectedImage!, fit: BoxFit.cover),
                            ),
                            Positioned(
                              top: 6,
                              right: 6,
                              child: CircleAvatar(
                                backgroundColor: Colors.black54,
                                radius: 14,
                                child: IconButton(
                                  padding: EdgeInsets.zero,
                                  icon: const Icon(Icons.close, size: 14, color: Colors.white),
                                  onPressed: () => setModalState(() => selectedImage = null),
                                ),
                              ),
                            ),
                          ],
                        )
                            : Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Icon(Icons.add_a_photo, size: 30, color: Colors.grey),
                            const SizedBox(height: 6),
                            Text(
                              "Add Photo (Optional)",
                              style: GoogleFonts.poppins(fontSize: 12, color: Colors.grey),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),

                    // Name Field
                    TextFormField(
                      controller: nameController,
                      style: TextStyle(color: isDarkMode ? Colors.white : Colors.black87),
                      decoration: InputDecoration(
                        labelText: "Category Name",
                        filled: true,
                        fillColor: isDarkMode ? Colors.grey.shade900 : Colors.grey.shade100,
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                      ),
                      validator: (val) => val == null || val.trim().isEmpty ? "Enter category name" : null,
                    ),
                    const SizedBox(height: 16),

                    // Description Field
                    TextFormField(
                      controller: descController,
                      style: TextStyle(color: isDarkMode ? Colors.white : Colors.black87),
                      decoration: InputDecoration(
                        labelText: "Description",
                        filled: true,
                        fillColor: isDarkMode ? Colors.grey.shade900 : Colors.grey.shade100,
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                      ),
                      maxLines: 2,
                    ),
                    const SizedBox(height: 24),

                    // Submit Button
                    SizedBox(
                      height: 50,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.indigo,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                          elevation: 0,
                        ),
                        onPressed: isSubmitting
                            ? null
                            : () async {
                          if (!formKey.currentState!.validate()) return;
                          setModalState(() => isSubmitting = true);

                          try {
                            final cafeUserName = await _resolveCafeUserName();
                            final String? accessToken = await _resolveAccessToken();

                            var request = http.MultipartRequest(
                              'POST',
                              Uri.parse('${AppConfig.baseUrl}/category/create'),
                            );

                            if (accessToken != null) {
                              request.headers['Authorization'] = 'Bearer $accessToken';
                            }

                            request.fields['name'] = nameController.text.trim();
                            request.fields['description'] = descController.text.trim();
                            request.fields['cafeUserName'] = cafeUserName;

                            if (selectedImage != null) {
                              request.files.add(
                                await http.MultipartFile.fromPath('image', selectedImage!.path),
                              );
                            }

                            var streamedResponse = await request.send();
                            var response = await http.Response.fromStream(streamedResponse);

                            if (response.statusCode == 200 || response.statusCode == 201) {
                              if (mounted) {
                                Navigator.pop(context);
                                _fetchCategories();
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(content: Text("Category created successfully")),
                                );
                              }
                            } else {
                              final decoded = jsonDecode(response.body);
                              if (mounted) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(content: Text(decoded['message'] ?? "Failed to create category")),
                                );
                              }
                            }
                          } catch (e) {
                            debugPrint("Create Category Error: $e");
                          } finally {
                            if (mounted) {
                              setModalState(() => isSubmitting = false);
                            }
                          }
                        },
                        child: isSubmitting
                            ? const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                        )
                            : Text(
                          "SAVE CATEGORY",
                          style: GoogleFonts.poppins(fontWeight: FontWeight.bold, color: Colors.white),
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}