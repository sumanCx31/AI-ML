import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import './createMenu.dart';
import '../../../core/config/app_config.dart';
import '../../../providers/auth_provider.dart';
import '../../../providers/staff_auth_provider.dart';
import '../../widgets/sipsnap_loading_logo.dar.dart'; // Professional animated logo import

class MenuPage extends StatefulWidget {
  const MenuPage({super.key});

  @override
  State<MenuPage> createState() => _MenuPageState();
}

class _MenuPageState extends State<MenuPage> {
  List<dynamic> _allMenus = [];
  List<dynamic> _filteredMenus = [];
  List<dynamic> _categories = [];

  String _selectedCategoryId = 'all';
  String _searchQuery = '';
  bool _isLoadingCategories = true;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _fetchCategories();
      _fetchMenus();
    });
  }

  Future<String?> _resolveAccessToken() async {
    final staffAuthProvider = context.read<StaffAuthProvider>();
    final authProvider = context.read<AuthProvider>();
    return staffAuthProvider.staffDetails != null ? null : authProvider.accessToken;
  }

  Future<String> _resolveCafeUserName() async {
    final staffAuthProvider = context.read<StaffAuthProvider>();
    final authProvider = context.read<AuthProvider>();
    return staffAuthProvider.staffDetails?['cafeUserName'] ??
        authProvider.user?.cafeUserName ??
        "cafe123456";
  }

  Future<void> _fetchCategories() async {
    try {
      final cafeUserName = await _resolveCafeUserName();
      final String? accessToken = await _resolveAccessToken();

      final response = await http.get(
        Uri.parse('${AppConfig.baseUrl}/category/all/$cafeUserName'),
        headers: {
          "Content-Type": "application/json",
          if (accessToken != null) 'Authorization': 'Bearer $accessToken',
        },
      );

      if (response.statusCode == 200) {
        final decoded = json.decode(response.body);
        if (mounted) {
          setState(() {
            _categories = decoded['data'] ?? [];
            _isLoadingCategories = false;
          });
        }
      } else {
        if (mounted) setState(() => _isLoadingCategories = false);
      }
    } catch (e) {
      debugPrint("Category API Error: $e");
      if (mounted) setState(() => _isLoadingCategories = false);
    }
  }

  Future<void> _fetchMenus() async {
    try {
      final cafeUserName = await _resolveCafeUserName();
      final String? accessToken = await _resolveAccessToken();

      final response = await http.get(
        Uri.parse('${AppConfig.baseUrl}/menu/cafe/$cafeUserName'),
        headers: {
          "Content-Type": "application/json",
          if (accessToken != null) 'Authorization': 'Bearer $accessToken',
        },
      );

      if (response.statusCode == 200) {
        final decoded = json.decode(response.body);
        if (mounted) {
          setState(() {
            _allMenus = decoded['data'] ?? [];
            _applyFilters();
          });
        }
      }
    } catch (e) {
      debugPrint("Menu API Error: $e");
    }
  }

  Future<void> _deleteMenu(String id) async {
    try {
      final String? accessToken = await _resolveAccessToken();
      final response = await http.delete(
        Uri.parse('${AppConfig.baseUrl}/menu/delete/$id'),
        headers: {
          "Content-Type": "application/json",
          if (accessToken != null) 'Authorization': 'Bearer $accessToken',
        },
      );

      if (response.statusCode == 200) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("Menu item deleted successfully")),
          );
        }
        _fetchMenus();
      }
    } catch (e) {
      debugPrint("Delete Error: $e");
    }
  }

  void _applyFilters() {
    setState(() {
      _filteredMenus = _allMenus.where((item) {
        final matchesSearch = item['name'].toString().toLowerCase().contains(_searchQuery.toLowerCase());

        bool matchesCategory = true;
        if (_selectedCategoryId != 'all') {
          final categoryField = item['category'];
          if (categoryField is Map) {
            matchesCategory = categoryField['_id'] == _selectedCategoryId;
          } else if (categoryField is String) {
            matchesCategory = categoryField == _selectedCategoryId;
          } else {
            matchesCategory = false;
          }
        }

        return matchesSearch && matchesCategory;
      }).toList();
    });
  }

  void _onSearchChanged(String query) {
    _searchQuery = query;
    _applyFilters();
  }

  void _onCategorySelected(String categoryId) {
    setState(() {
      _selectedCategoryId = categoryId;
    });
    _applyFilters();
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text(
          "Menu Management",
          style: GoogleFonts.poppins(
            color: isDarkMode ? Colors.white : Colors.black,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: IconThemeData(color: isDarkMode ? Colors.white : Colors.black87),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.indigo,
        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (context) => const CreateMenuPage()))
            .then((_) => _fetchMenus()),
        child: const Icon(Icons.add, color: Colors.white),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: TextField(
              decoration: InputDecoration(
                hintText: "Search menu...",
                hintStyle: TextStyle(color: Colors.grey.shade500),
                prefixIcon: const Icon(Icons.search, color: Colors.grey),
                filled: true,
                fillColor: Theme.of(context).cardColor,
                border: const OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(15)), borderSide: BorderSide.none),
              ),
              style: TextStyle(color: isDarkMode ? Colors.white : Colors.black87),
              onChanged: _onSearchChanged,
            ),
          ),
          Container(
            height: 55,
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: _isLoadingCategories
                ? const Center(
              // Integrated your clean professional small logo for loading categories
              child: SipSnapAnimatedLogo(fontSize: 18),
            )
                : ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: [
                _buildFilterChip('all', 'All Items', isDarkMode),
                ..._categories.map((cat) => _buildFilterChip(cat['_id'], cat['name'], isDarkMode)),
              ],
            ),
          ),
          Expanded(
            child: _filteredMenus.isEmpty
                ? Center(
              child: Text("No menu items found", style: GoogleFonts.poppins(color: Colors.grey.shade500)),
            )
                : GridView.builder(
              padding: const EdgeInsets.all(16),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 16,
                mainAxisSpacing: 16,
                childAspectRatio: 0.75,
              ),
              itemCount: _filteredMenus.length,
              itemBuilder: (context, index) => _buildMenuCard(_filteredMenus[index], isDarkMode),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterChip(String id, String label, bool isDarkMode) {
    bool isSelected = _selectedCategoryId == id;
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ChoiceChip(
        label: Text(label),
        selected: isSelected,
        selectedColor: Colors.indigo,
        backgroundColor: isDarkMode ? Colors.grey.shade800 : Colors.white,
        labelStyle: GoogleFonts.poppins(
          color: isSelected ? Colors.white : (isDarkMode ? Colors.white70 : Colors.black87),
          fontWeight: FontWeight.w500,
          fontSize: 13,
        ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        onSelected: (_) => _onCategorySelected(id),
      ),
    );
  }

  Widget _buildMenuCard(dynamic item, bool isDarkMode) {
    final String imageUrl = item['image']?['secureUrl'] ?? "";

    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: ClipRRect(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
              child: imageUrl.isNotEmpty
                  ? Image.network(imageUrl, fit: BoxFit.cover, width: double.infinity)
                  : Container(color: isDarkMode ? Colors.grey.shade900 : Colors.grey[200], child: const Center(child: Icon(Icons.fastfood, color: Colors.grey))),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Text(
                        item['name'] ?? 'Item',
                        style: GoogleFonts.poppins(
                          fontWeight: FontWeight.bold,
                          color: isDarkMode ? Colors.white : Colors.black87,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    PopupMenuButton<String>(
                      padding: EdgeInsets.zero,
                      color: Theme.of(context).cardColor,
                      itemBuilder: (context) => [
                        PopupMenuItem(
                          value: 'edit',
                          child: Text("Edit", style: TextStyle(color: isDarkMode ? Colors.white : Colors.black87)),
                        ),
                        PopupMenuItem(
                          value: 'delete',
                          child: Text("Delete", style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
                        ),
                      ],
                      onSelected: (val) {
                        if (val == 'delete' && item['_id'] != null) {
                          _deleteMenu(item['_id']);
                        } else {
                          debugPrint("Navigate to Edit");
                        }
                      },
                    )
                  ],
                ),
                Text(
                  "Rs. ${item['price'] ?? 0}",
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: isDarkMode ? Colors.greenAccent : Colors.green.shade700,
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}