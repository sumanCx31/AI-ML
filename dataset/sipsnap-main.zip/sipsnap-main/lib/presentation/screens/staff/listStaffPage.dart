import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:animate_do/animate_do.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';
import '../../../providers/auth_provider.dart';
import '../../../core/config/app_config.dart';

class ListStaffPage extends StatefulWidget {
  final String cafeUserName;

  const ListStaffPage({
    super.key,
    required this.cafeUserName,
  });

  @override
  State<ListStaffPage> createState() => _ListStaffPageState();
}

class _ListStaffPageState extends State<ListStaffPage> {
  bool _isLoading = true;
  List<dynamic> _staffList = [];
  List<dynamic> _filteredStaffList = [];
  final TextEditingController _searchController = TextEditingController();

  // Track IDs of users whose status is currently being updated to prevent multi-clicks
  final Set<String> _togglingUserIds = {};

  @override
  void initState() {
    super.initState();
    _fetchStaff();
    _searchController.addListener(_filterStaff);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _fetchStaff() async {
    try {
      final authProvider = context.read<AuthProvider>();
      final accessToken = authProvider.accessToken;
      final currentUsername = authProvider.user?.name ?? '';

      final url = Uri.parse('${AppConfig.baseUrl}/auth/user/${widget.cafeUserName}');
      final response = await http.get(
        url,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $accessToken',
        },
      );

      if (response.statusCode == 200) {
        final decoded = jsonDecode(response.body);
        List<dynamic> allUsers = decoded['data']?['Users'] ?? [];

        // Filter out the currently logged-in user
        final filteredUsers = allUsers.where((user) {
          final username = user['userName'] ?? user['email'] ?? '';
          return username != currentUsername;
        }).toList();

        if (mounted) {
          setState(() {
            _staffList = filteredUsers;
            _filteredStaffList = _staffList;
            _isLoading = false;
          });
        }
      } else {
        if (mounted) setState(() => _isLoading = false);
      }
    } catch (e) {
      if (mounted) setState(() => _isLoading = false);
      debugPrint("Error fetching staff list: $e");
    }
  }

  Future<void> _toggleUserStatus(String userId, int index) async {
    if (_togglingUserIds.contains(userId)) return;

    setState(() {
      _togglingUserIds.add(userId);
      // Optimistically toggle status locally
      final staff = _staffList[index];
      final currentStatus = staff['status'] ?? 'ACTIVE';
      staff['status'] = (currentStatus == 'ACTIVE') ? 'INACTIVE' : 'ACTIVE';
    });

    try {
      final accessToken = context.read<AuthProvider>().accessToken;
      final url = Uri.parse('${AppConfig.baseUrl}/auth/toggle-user-status/$userId');

      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $accessToken',
        },
      );

      final decoded = jsonDecode(response.body);

      if (response.statusCode == 200) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(decoded['message'] ?? "User status updated successfully")),
          );
          _fetchStaff();
        }
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(decoded['message'] ?? "Failed to update user status")),
          );
          _fetchStaff();
        }
      }
    } catch (e) {
      debugPrint("Error toggling user status: $e");
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Network error while updating user status")),
        );
        _fetchStaff();
      }
    } finally {
      if (mounted) {
        setState(() {
          _togglingUserIds.remove(userId);
        });
      }
    }
  }

  Future<void> _createStaff({
    required String name,
    required String email,
    required String phone,
    required String userName,
    required String password,
    required String role,
  }) async {
    try {
      final accessToken = context.read<AuthProvider>().accessToken;

      final url = Uri.parse('${AppConfig.baseUrl}/auth/register');
      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $accessToken',
        },
        body: jsonEncode({
          "name": name,
          "email": email,
          "phone": phone,
          "userName": userName,
          "password": password,
          "confirmPassword": password,
          "role": role,
          "cafeUserName": widget.cafeUserName,
        }),
      );

      final decoded = jsonDecode(response.body);

      if (response.statusCode == 201 || response.statusCode == 200) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(decoded['message'] ?? "Staff created successfully")),
          );
          _fetchStaff();
        }
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(decoded['message'] ?? "Failed to create staff")),
          );
        }
      }
    } catch (e) {
      debugPrint("Error creating staff: $e");
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Network error while creating staff")),
        );
      }
    }
  }

  Future<void> _updateStaff({
    required String staffId,
    required String name,
    required String email,
    required String phone,
    required String userName,
    required String role,
    String? password,
  }) async {
    try {
      final accessToken = context.read<AuthProvider>().accessToken;
      final url = Uri.parse('${AppConfig.baseUrl}/auth/register/$staffId');

      final Map<String, dynamic> body = {
        "name": name,
        "email": email,
        "phone": phone,
        "userName": userName,
        "role": role,
        "cafeUserName": widget.cafeUserName,
      };

      if (password != null && password.isNotEmpty) {
        body["password"] = password;
        body["confirmPassword"] = password;
      }

      final response = await http.put(
        url,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $accessToken',
        },
        body: jsonEncode(body),
      );

      final decoded = jsonDecode(response.body);

      if (response.statusCode == 200) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(decoded['message'] ?? "Staff updated successfully")),
          );
          _fetchStaff();
        }
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(decoded['message'] ?? "Failed to update staff")),
          );
        }
      }
    } catch (e) {
      debugPrint("Error updating staff: $e");
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Network error while updating staff")),
        );
      }
    }
  }

  void _filterStaff() {
    final query = _searchController.text.toLowerCase();
    setState(() {
      _filteredStaffList = _staffList.where((staff) {
        final userName = (staff['userName'] ?? staff['name'] ?? '').toLowerCase();
        final email = (staff['email'] ?? '').toLowerCase();
        final name = (staff['name'] ?? '').toLowerCase();
        return userName.contains(query) || email.contains(query) || name.contains(query);
      }).toList();
    });
  }

  void _showAddEditStaffModal(bool isDarkMode, {Map<String, dynamic>? staff}) {
    final isEditing = staff != null;
    final nameController = TextEditingController(text: staff?['name'] ?? '');
    final emailController = TextEditingController(text: staff?['email'] ?? '');
    final phoneController = TextEditingController(text: staff?['phone'] ?? '');
    final userNameController = TextEditingController(text: staff?['userName'] ?? '');
    final passwordController = TextEditingController();
    String selectedRole = staff?['role']?.toLowerCase() ?? 'admin';

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => StatefulBuilder(
        builder: (context, setModalState) => Container(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom,
            left: 20,
            right: 20,
            top: 25,
          ),
          decoration: BoxDecoration(
            color: Theme.of(context).cardColor,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(30)),
          ),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: Colors.grey.shade600,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                Text(
                  isEditing ? "Edit User Member" : "Add New User",
                  style: GoogleFonts.poppins(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: isDarkMode ? Colors.white : Colors.black87,
                  ),
                ),
                const SizedBox(height: 20),
                _buildTextField("Full Name", nameController, PhosphorIcons.user, isDarkMode),
                const SizedBox(height: 15),
                _buildTextField("Email Address", emailController, PhosphorIcons.envelope, isDarkMode),
                const SizedBox(height: 15),
                _buildTextField("Phone Number", phoneController, PhosphorIcons.phone, isDarkMode, keyboardType: TextInputType.phone),
                const SizedBox(height: 15),
                _buildTextField("Username", userNameController, PhosphorIcons.at, isDarkMode),
                const SizedBox(height: 15),
                _buildTextField(
                  isEditing ? "New Password (Optional)" : "Password",
                  passwordController,
                  PhosphorIcons.lock,
                  isDarkMode,
                  obscureText: true,
                ),
                const SizedBox(height: 15),
                DropdownButtonFormField<String>(
                  value: selectedRole,
                  dropdownColor: Theme.of(context).cardColor,
                  style: TextStyle(color: isDarkMode ? Colors.white : Colors.black87),
                  decoration: InputDecoration(
                    labelText: "Role",
                    labelStyle: TextStyle(color: isDarkMode ? Colors.white70 : Colors.black54),
                    prefixIcon: const Icon(PhosphorIcons.shieldCheck, color: Colors.indigo),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                    filled: true,
                    fillColor: isDarkMode ? Colors.grey.shade900 : const Color(0xFFF8F9FE),
                  ),
                  items: ['admin', 'manager', 'staff'].map((role) {
                    return DropdownMenuItem(
                      value: role,
                      child: Text(
                        role.toUpperCase(),
                        style: TextStyle(color: isDarkMode ? Colors.white : Colors.black87),
                      ),
                    );
                  }).toList(),
                  onChanged: (val) {
                    if (val != null) setModalState(() => selectedRole = val);
                  },
                ),
                const SizedBox(height: 30),
                SizedBox(
                  width: double.infinity,
                  height: 55,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF6366F1),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      elevation: 0,
                    ),
                    onPressed: () async {
                      Navigator.pop(context);
                      if (isEditing) {
                        await _updateStaff(
                          staffId: staff['_id'],
                          name: nameController.text.trim(),
                          email: emailController.text.trim(),
                          phone: phoneController.text.trim(),
                          userName: userNameController.text.trim(),
                          role: selectedRole,
                          password: passwordController.text.trim(),
                        );
                      } else {
                        await _createStaff(
                          name: nameController.text.trim(),
                          email: emailController.text.trim(),
                          phone: phoneController.text.trim(),
                          userName: userNameController.text.trim(),
                          password: passwordController.text.trim(),
                          role: selectedRole,
                        );
                      }
                    },
                    child: Text(
                      isEditing ? "Update User" : "Create User",
                      style: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.w600, color: Colors.white),
                    ),
                  ),
                ),
                const SizedBox(height: 30),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(String label, TextEditingController controller, IconData icon, bool isDarkMode, {bool obscureText = false, TextInputType keyboardType = TextInputType.text}) {
    return TextField(
      controller: controller,
      obscureText: obscureText,
      keyboardType: keyboardType,
      style: TextStyle(color: isDarkMode ? Colors.white : Colors.black87),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: TextStyle(color: isDarkMode ? Colors.white70 : Colors.black54),
        prefixIcon: Icon(icon, color: Colors.indigo),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
        filled: true,
        fillColor: isDarkMode ? Colors.grey.shade900 : const Color(0xFFF8F9FE),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text(
          "Cafe Users",
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.bold,
            color: isDarkMode ? Colors.white : Colors.black87,
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        iconTheme: IconThemeData(color: isDarkMode ? Colors.white : Colors.black87),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            children: [
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                        color: Theme.of(context).cardColor,
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(isDarkMode ? 0.2 : 0.04),
                            blurRadius: 10,
                          ),
                        ],
                      ),
                      child: TextField(
                        controller: _searchController,
                        style: TextStyle(color: isDarkMode ? Colors.white : Colors.black87),
                        decoration: InputDecoration(
                          hintText: "Search by username or email...",
                          hintStyle: TextStyle(color: isDarkMode ? Colors.white60 : Colors.grey.shade400, fontSize: 14),
                          prefixIcon: const Icon(PhosphorIcons.magnifyingGlass, color: Colors.indigo),
                          border: InputBorder.none,
                          contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Container(
                    height: 52,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(colors: [Color(0xFF6366F1), Color(0xFFA855F7)]),
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [BoxShadow(color: Colors.indigo.withOpacity(0.3), blurRadius: 10, offset: const Offset(0, 4))],
                    ),
                    child: IconButton(
                      icon: const Icon(Icons.add, color: Colors.white, size: 26),
                      onPressed: () => _showAddEditStaffModal(isDarkMode),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              Expanded(
                child: _isLoading
                    ? const Center(child: CircularProgressIndicator(color: Colors.indigo))
                    : _filteredStaffList.isEmpty
                    ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(PhosphorIcons.users, size: 60, color: Colors.grey.shade600),
                      const SizedBox(height: 10),
                      Text(
                        "No users found",
                        style: GoogleFonts.poppins(color: isDarkMode ? Colors.white60 : Colors.grey.shade500, fontSize: 16),
                      ),
                    ],
                  ),
                )
                    : ListView.builder(
                  itemCount: _filteredStaffList.length,
                  itemBuilder: (context, index) {
                    final staff = _filteredStaffList[index];
                    final userId = staff['_id'] ?? '';
                    final imageUrl = staff['image'] is Map ? (staff['image']['secureUrl'] ?? '') : '';

                    final String status = staff['status'] ?? 'ACTIVE';
                    final bool isActive = status == 'ACTIVE';
                    final bool isToggling = _togglingUserIds.contains(userId);

                    return FadeInUp(
                      delay: Duration(milliseconds: index * 50),
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 15),
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Theme.of(context).cardColor,
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(isDarkMode ? 0.2 : 0.04),
                              blurRadius: 10,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: Row(
                          children: [
                            CircleAvatar(
                              radius: 26,
                              backgroundColor: isDarkMode ? Colors.indigo.shade900.withOpacity(0.5) : Colors.indigo.shade50,
                              backgroundImage: imageUrl.isNotEmpty ? NetworkImage(imageUrl) : null,
                              child: imageUrl.isEmpty
                                  ? Text(
                                staff['name'] != null && staff['name'].isNotEmpty ? staff['name'][0].toUpperCase() : "U",
                                style: GoogleFonts.poppins(color: Colors.indigoAccent, fontWeight: FontWeight.bold, fontSize: 18),
                              )
                                  : null,
                            ),
                            const SizedBox(width: 15),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Expanded(
                                        child: Text(
                                          staff['name'] ?? "Unknown",
                                          style: GoogleFonts.poppins(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 16,
                                            color: isDarkMode ? Colors.white : Colors.black87,
                                          ),
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                      const SizedBox(width: 8),
                                      Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                        decoration: BoxDecoration(
                                          color: Colors.indigo.withOpacity(0.1),
                                          borderRadius: BorderRadius.circular(6),
                                        ),
                                        child: Text(
                                          (staff['role'] ?? 'staff').toUpperCase(),
                                          style: const TextStyle(color: Colors.indigoAccent, fontSize: 10, fontWeight: FontWeight.bold),
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 2),
                                  Text(
                                    staff['email'] ?? '',
                                    style: TextStyle(color: isDarkMode ? Colors.white70 : Colors.grey.shade600, fontSize: 13),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  const SizedBox(height: 4),
                                  Row(
                                    children: [
                                      Text(
                                        "Phone: ${staff['phone'] != null && staff['phone'].toString().isNotEmpty ? staff['phone'] : 'N/A'}",
                                        style: TextStyle(color: isDarkMode ? Colors.white60 : Colors.grey.shade500, fontSize: 12),
                                      ),
                                      const SizedBox(width: 10),
                                      // Status Badge indicator next to phone info
                                      Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                                        decoration: BoxDecoration(
                                          color: isActive ? Colors.green.withOpacity(0.1) : Colors.red.withOpacity(0.1),
                                          borderRadius: BorderRadius.circular(4),
                                        ),
                                        child: Text(
                                          status,
                                          style: TextStyle(
                                            color: isActive ? Colors.green : Colors.red,
                                            fontSize: 9,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 8),
                            // Edit Button
                            IconButton(
                              icon: const Icon(PhosphorIcons.pencilSimple, color: Colors.indigoAccent, size: 22),
                              onPressed: () => _showAddEditStaffModal(isDarkMode, staff: staff),
                              constraints: const BoxConstraints(),
                              padding: const EdgeInsets.all(4),
                            ),
                            const SizedBox(width: 4),
                            // Switch Toggle with API lock protection
                            Switch(
                              value: isActive,
                              activeColor: Colors.green,
                              inactiveTrackColor: Colors.red.withOpacity(0.3),
                              inactiveThumbColor: Colors.red,
                              onChanged: isToggling
                                  ? null
                                  : (bool value) {
                                _toggleUserStatus(userId, index);
                              },
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}