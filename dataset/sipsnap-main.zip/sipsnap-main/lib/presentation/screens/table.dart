import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:google_fonts/google_fonts.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:provider/provider.dart';
import './createTable.dart';
import '../../../core/config/app_config.dart';
import '../../../providers/auth_provider.dart';
import '../../../providers/staff_auth_provider.dart';
import '../../presentation/widgets/sipsnap_loading_logo.dar.dart';

class TablePage extends StatefulWidget {
  const TablePage({super.key});

  @override
  State<TablePage> createState() => _TablePageState();
}

class _TablePageState extends State<TablePage> {
  List<dynamic> _allTables = [];
  List<dynamic> _filteredTables = [];
  bool _isLoading = true;
  String _searchQuery = "";
  String _statusFilter = "All";

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _fetchTables();
    });
  }

  Future<String?> _resolveAccessToken() async {
    final staffAuthProvider = context.read<StaffAuthProvider>();
    final authProvider = context.read<AuthProvider>();
    return staffAuthProvider.staffDetails != null ? null : authProvider.accessToken;
  }

  Future<void> _fetchTables() async {
    setState(() => _isLoading = true);

    final staffAuthProvider = context.read<StaffAuthProvider>();
    final authProvider = context.read<AuthProvider>();

    final String cafeUserName = staffAuthProvider.staffDetails?['cafeUserName'] ??
        authProvider.user?.cafeUserName ??
        "cafe123456";

    final String apiUrl = '${AppConfig.baseUrl}/table/$cafeUserName';
    final String? accessToken = await _resolveAccessToken();

    try {
      final response = await http.get(
        Uri.parse(apiUrl),
        headers: {
          "Content-Type": "application/json",
          if (accessToken != null) 'Authorization': 'Bearer $accessToken',
        },
      );
      if (response.statusCode == 200) {
        final decoded = json.decode(response.body);
        final data = decoded['data'] ?? [];
        if (mounted) {
          setState(() {
            _allTables = data;
            _applyFilters();
            _isLoading = false;
          });
        }
      } else {
        if (mounted) setState(() => _isLoading = false);
      }
    } catch (e) {
      debugPrint("Error fetching tables: $e");
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _deleteTable(String tableId, bool isDarkMode) async {
    bool? confirm = await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Theme.of(context).cardColor,
        title: Text(
          "Delete Table",
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.bold,
            color: isDarkMode ? Colors.white : Colors.black87,
          ),
        ),
        content: Text(
          "Are you sure you want to delete this table? This action cannot be undone.",
          style: GoogleFonts.poppins(color: isDarkMode ? Colors.white70 : Colors.black54),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text("CANCEL", style: TextStyle(color: isDarkMode ? Colors.white70 : Colors.black54)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text("DELETE", style: GoogleFonts.poppins(color: Colors.red, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );

    if (confirm == true) {
      final String? accessToken = await _resolveAccessToken();
      final String apiUrl = '${AppConfig.baseUrl}/table/$tableId';

      try {
        final response = await http.delete(
          Uri.parse(apiUrl),
          headers: {
            "Content-Type": "application/json",
            if (accessToken != null) 'Authorization': 'Bearer $accessToken',
          },
        );

        if (response.statusCode == 200) {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text("Table deleted successfully")),
            );
          }
          _fetchTables();
        } else {
          final decoded = json.decode(response.body);
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(decoded['message'] ?? "Failed to delete table")),
            );
          }
        }
      } catch (e) {
        debugPrint("Error deleting table: $e");
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("Network error while deleting table")),
          );
        }
      }
    }
  }

  void _applyFilters() {
    setState(() {
      _filteredTables = _allTables.where((table) {
        final matchesSearch = table['name'].toString().toLowerCase().contains(_searchQuery.toLowerCase());
        final matchesStatus = _statusFilter == "All" || table['status'].toString().toLowerCase() == _statusFilter.toLowerCase();
        return matchesSearch && matchesStatus;
      }).toList();
    });
  }

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'available':
        return Colors.green;
      case 'occupied':
        return Colors.red;
      case 'reserved':
        return Colors.amber;
      case 'cleaning':
        return Colors.blue;
      default:
        return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text(
          "Manage Tables",
          style: GoogleFonts.poppins(
            color: isDarkMode ? Colors.white : Colors.black,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: IconThemeData(color: isDarkMode ? Colors.white : Colors.black87),
      ),
      body: Column(
        children: [
          _buildLegend(isDarkMode),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    decoration: InputDecoration(
                      hintText: "Search tables...",
                      hintStyle: TextStyle(color: Colors.grey.shade500),
                      prefixIcon: const Icon(Icons.search, color: Colors.grey),
                      filled: true,
                      fillColor: Theme.of(context).cardColor,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide.none,
                      ),
                    ),
                    style: TextStyle(color: isDarkMode ? Colors.white : Colors.black87),
                    onChanged: (v) {
                      _searchQuery = v;
                      _applyFilters();
                    },
                  ),
                ),
                const SizedBox(width: 10),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  decoration: BoxDecoration(
                    color: Theme.of(context).cardColor,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<String>(
                      value: _statusFilter,
                      dropdownColor: Theme.of(context).cardColor,
                      style: GoogleFonts.poppins(
                        fontSize: 13,
                        color: isDarkMode ? Colors.white : Colors.black87,
                        fontWeight: FontWeight.w500,
                      ),
                      items: ["All", "Available", "Occupied", "Reserved", "Cleaning"]
                          .map((s) => DropdownMenuItem(value: s, child: Text(s)))
                          .toList(),
                      onChanged: (v) {
                        setState(() {
                          _statusFilter = v!;
                          _applyFilters();
                        });
                      },
                    ),
                  ),
                )
              ],
            ),
          ),
          const SizedBox(height: 10),
          Expanded(
            child: _isLoading
                ? const Center(
              // Made the logo small and professional for loading states
              child: SipSnapAnimatedLogo(fontSize: 22),
            )
                : GridView.builder(
              padding: const EdgeInsets.all(20),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 15,
                mainAxisSpacing: 15,
              ),
              itemCount: _filteredTables.length + 1,
              itemBuilder: (context, index) {
                if (index == _filteredTables.length) return _buildAddTableCard(isDarkMode);
                return _buildTableCard(_filteredTables[index], isDarkMode);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLegend(bool isDarkMode) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      child: Row(
        children: [
          {"color": Colors.green, "text": "Avail"},
          {"color": Colors.red, "text": "Occ"},
          {"color": Colors.amber, "text": "Res"},
          {"color": Colors.blue, "text": "Clean"}
        ]
            .map((l) => Padding(
          padding: const EdgeInsets.only(right: 15),
          child: Row(
            children: [
              CircleAvatar(radius: 6, backgroundColor: l['color'] as Color),
              const SizedBox(width: 5),
              Text(
                l['text'] as String,
                style: TextStyle(
                  fontSize: 12,
                  color: isDarkMode ? Colors.white70 : Colors.black87,
                ),
              ),
            ],
          ),
        ))
            .toList(),
      ),
    );
  }

  Widget _buildTableCard(dynamic table, bool isDarkMode) {
    Color statusColor = _getStatusColor(table['status'] ?? 'available');
    final tableId = table['_id'] ?? table['id'];

    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: statusColor, width: 2),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Align(
            alignment: Alignment.topRight,
            child: PopupMenuButton<String>(
              color: Theme.of(context).cardColor,
              icon: Icon(Icons.more_vert, size: 18, color: isDarkMode ? Colors.white70 : Colors.black87),
              onSelected: (val) {
                if (val == 'delete' && tableId != null) {
                  _deleteTable(tableId, isDarkMode);
                } else if (val == 'edit') {
                  // TODO: Add edit navigation if necessary
                }
              },
              itemBuilder: (ctx) => [
                PopupMenuItem(
                  value: 'edit',
                  child: Text('Edit', style: TextStyle(color: isDarkMode ? Colors.white : Colors.black87)),
                ),
                PopupMenuItem(
                  value: 'delete',
                  child: Text('Delete', style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
                ),
              ],
            ),
          ),
          Icon(PhosphorIcons.table, size: 30, color: statusColor),
          const SizedBox(height: 8),
          Text(
            table['name'] ?? 'Table',
            style: GoogleFonts.poppins(
              fontWeight: FontWeight.bold,
              color: isDarkMode ? Colors.white : Colors.black87,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            (table['status'] ?? 'unknown').toUpperCase(),
            style: TextStyle(color: statusColor, fontSize: 10, fontWeight: FontWeight.bold),
          ),
          const Spacer(),
        ],
      ),
    );
  }

  Widget _buildAddTableCard(bool isDarkMode) {
    return InkWell(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (c) => const CreateTablePage()),
      ).then((_) => _fetchTables()),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.indigo.withOpacity(isDarkMode ? 0.2 : 0.1),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: Colors.indigo, style: BorderStyle.solid),
        ),
        child: const Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.add, color: Colors.indigo, size: 32),
            SizedBox(height: 8),
            Text(
              "Add",
              style: TextStyle(color: Colors.indigo, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}