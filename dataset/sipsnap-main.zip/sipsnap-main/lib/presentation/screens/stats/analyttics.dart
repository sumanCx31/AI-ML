import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import '../../../core/config/app_config.dart';

class AnalyticsDashboard extends StatefulWidget {
  final String cafeUserName;
  const AnalyticsDashboard({super.key, required this.cafeUserName});

  @override
  _AnalyticsDashboardState createState() => _AnalyticsDashboardState();
}

class _AnalyticsDashboardState extends State<AnalyticsDashboard> {
  Map<String, dynamic> stats = {};
  List<dynamic> bestSelling = [];
  bool isLoading = true;

  // Filter state variables
  String selectedFilter = 'today'; // options: today, yesterday, thisWeek, thisMonth, custom
  DateTime? customStartDate;
  DateTime? customEndDate;

  @override
  void initState() {
    super.initState();
    _fetchData();
  }

  Future<void> _fetchData() async {
    setState(() => isLoading = true);
    try {
      String queryParams = '?filter=$selectedFilter';
      if (selectedFilter == 'custom' && customStartDate != null && customEndDate != null) {
        String startStr = customStartDate!.toIso8601String().split('T')[0];
        String endStr = customEndDate!.toIso8601String().split('T')[0];
        queryParams += '&startDate=$startStr&endDate=$endStr';
      }

      final statsUrl = Uri.parse('${AppConfig.baseUrl}/analytics/dashboard/${widget.cafeUserName}$queryParams');
      final bestUrl = Uri.parse('${AppConfig.baseUrl}/analytics/best-selling/${widget.cafeUserName}$queryParams');

      debugPrint("Fetching stats from: $statsUrl");
      debugPrint("Fetching best-selling from: $bestUrl");

      final statsRes = await http.get(statsUrl);
      final bestRes = await http.get(bestUrl);

      if (statsRes.statusCode == 200) {
        final decodedStats = jsonDecode(statsRes.body);
        if (decodedStats is Map<String, dynamic>) {
          stats = decodedStats;
        }
      } else {
        debugPrint("Stats API Error: ${statsRes.statusCode} - ${statsRes.body}");
      }

      if (bestRes.statusCode == 200) {
        final decodedBest = jsonDecode(bestRes.body);
        if (decodedBest is Map<String, dynamic>) {
          bestSelling = decodedBest['data'] ?? decodedBest['bestSelling'] ?? [];
        } else if (decodedBest is List) {
          bestSelling = decodedBest;
        }
      } else {
        debugPrint("Best Selling API Error: ${bestRes.statusCode} - ${bestRes.body}");
      }
    } catch (e) {
      debugPrint("Analytics Fetch Error: $e");
    } finally {
      if (mounted) {
        setState(() => isLoading = false);
      }
    }
  }

  Future<void> _selectCustomDateRange() async {
    final DateTimeRange? picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2023),
      lastDate: DateTime.now(),
      initialDateRange: customStartDate != null && customEndDate != null
          ? DateTimeRange(start: customStartDate!, end: customEndDate!)
          : DateTimeRange(start: DateTime.now().subtract(const Duration(days: 7)), end: DateTime.now()),
    );

    if (picked != null) {
      setState(() {
        customStartDate = picked.start;
        customEndDate = picked.end;
        selectedFilter = 'custom';
      });
      _fetchData();
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text(
          "Analytics Dashboard",
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.bold,
            color: isDarkMode ? Colors.white : Colors.black,
          ),
        ),
        elevation: 0,
      ),
      body: Column(
        children: [
          _buildFilterBar(isDarkMode),
          Expanded(
            child: isLoading
                ? const Center(child: CircularProgressIndicator(color: Colors.indigo))
                : RefreshIndicator(
              onRefresh: _fetchData,
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildStatsGrid(isDarkMode),
                    const SizedBox(height: 25),
                    Text(
                      "Best Selling Items",
                      style: GoogleFonts.poppins(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: isDarkMode ? Colors.white : Colors.black87,
                      ),
                    ),
                    const SizedBox(height: 10),
                    bestSelling.isEmpty
                        ? Padding(
                      padding: const EdgeInsets.symmetric(vertical: 40.0),
                      child: Center(
                        child: Text(
                          "No items sold in this period",
                          style: GoogleFonts.poppins(color: Colors.grey.shade500, fontSize: 14),
                        ),
                      ),
                    )
                        : Column(
                      children: bestSelling.map((item) => _buildBestSellingCard(item, isDarkMode)).toList(),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterBar(bool isDarkMode) {
    return Container(
      color: Theme.of(context).cardColor,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            _filterChip("Today", "today", isDarkMode),
            _filterChip("Yesterday", "yesterday", isDarkMode),
            _filterChip("This Week", "thisWeek", isDarkMode),
            _filterChip("This Month", "thisMonth", isDarkMode),
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: ActionChip(
                label: Text(
                  selectedFilter == 'custom' && customStartDate != null && customEndDate != null
                      ? "${customStartDate!.toIso8601String().split('T')[0]} to ${customEndDate!.toIso8601String().split('T')[0]}"
                      : "Custom Range",
                  style: GoogleFonts.poppins(
                    fontSize: 13,
                    color: selectedFilter == 'custom' ? Colors.white : (isDarkMode ? Colors.white70 : Colors.black87),
                    fontWeight: FontWeight.w500,
                  ),
                ),
                backgroundColor: selectedFilter == 'custom' ? Colors.indigo : (isDarkMode ? Colors.grey.shade800 : Colors.grey.shade200),
                onPressed: _selectCustomDateRange,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _filterChip(String label, String value, bool isDarkMode) {
    bool isSelected = selectedFilter == value;
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ChoiceChip(
        label: Text(label, style: GoogleFonts.poppins(fontSize: 13, fontWeight: FontWeight.w500)),
        selected: isSelected,
        selectedColor: Colors.indigo,
        backgroundColor: isDarkMode ? Colors.grey.shade800 : Colors.grey.shade200,
        labelStyle: TextStyle(color: isSelected ? Colors.white : (isDarkMode ? Colors.white70 : Colors.black87)),
        onSelected: (bool selected) {
          if (selected) {
            setState(() {
              selectedFilter = value;
            });
            _fetchData();
          }
        },
      ),
    );
  }

  Widget _buildStatsGrid(bool isDarkMode) {
    double totalRevenue = double.tryParse((stats['totalRevenue'] ?? 0).toString()) ?? 0.0;
    double avgOrderValue = double.tryParse((stats['averageOrderValue'] ?? 0).toString()) ?? 0.0;
    int periodOrders = int.tryParse((stats['periodOrders'] ?? 0).toString()) ?? 0;
    int completedOrders = int.tryParse((stats['completedOrders'] ?? 0).toString()) ?? 0;

    return GridView.count(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisCount: 2,
      mainAxisSpacing: 16,
      crossAxisSpacing: 16,
      childAspectRatio: 1.5,
      children: [
        _statCard("Total Revenue", "Rs. ${totalRevenue.toStringAsFixed(0)}", Icons.attach_money, Colors.green, isDarkMode),
        _statCard("Avg Order Value", "Rs. ${avgOrderValue.toStringAsFixed(1)}", Icons.show_chart, Colors.blue, isDarkMode),
        _statCard("Period Orders", "$periodOrders", Icons.shopping_bag, Colors.orange, isDarkMode),
        _statCard("Completed", "$completedOrders", Icons.check_circle, Colors.purple, isDarkMode),
      ],
    );
  }

  Widget _statCard(String title, String value, IconData icon, Color color, bool isDarkMode) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, 5))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: color),
          const Spacer(),
          Text(
            value,
            style: GoogleFonts.poppins(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: isDarkMode ? Colors.white : Colors.black87,
            ),
          ),
          Text(title, style: GoogleFonts.poppins(fontSize: 11, color: Colors.grey)),
        ],
      ),
    );
  }

  Widget _buildBestSellingCard(dynamic item, bool isDarkMode) {
    return Card(
      elevation: 0,
      color: Theme.of(context).cardColor,
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: ListTile(
        leading: ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: Image.network(
            item['image'] ?? item['imageUrl'] ?? '',
            width: 50,
            height: 50,
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => const Icon(Icons.fastfood, size: 30, color: Colors.orange),
          ),
        ),
        title: Text(
          item['name'] ?? item['itemName'] ?? 'Item',
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.w600,
            color: isDarkMode ? Colors.white : Colors.black87,
          ),
        ),
        subtitle: Text(
          "Sold: ${item['totalSold'] ?? item['quantity'] ?? 0}",
          style: GoogleFonts.poppins(color: Colors.grey.shade400),
        ),
        trailing: Text(
          "Rs. ${item['totalRevenue'] ?? item['revenue'] ?? 0}",
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.bold,
            color: isDarkMode ? Colors.greenAccent : Colors.green.shade700,
          ),
        ),
      ),
    );
  }
}