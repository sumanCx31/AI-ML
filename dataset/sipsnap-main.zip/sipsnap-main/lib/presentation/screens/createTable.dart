import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../../../core/config/app_config.dart';
import '../../../providers/auth_provider.dart';
import '../../../providers/staff_auth_provider.dart';
import './widgets/custom_text_field.dart';

class CreateTablePage extends StatefulWidget {
  const CreateTablePage({super.key});

  @override
  State<CreateTablePage> createState() => _CreateTablePageState();
}

class _CreateTablePageState extends State<CreateTablePage> {
  final _nameController = TextEditingController();
  final _capacityController = TextEditingController();
  bool _isLoading = false;

  @override
  void dispose() {
    _nameController.dispose();
    _capacityController.dispose();
    super.dispose();
  }

  Future<String?> _resolveAccessToken() async {
    final staffAuthProvider = context.read<StaffAuthProvider>();
    final authProvider = context.read<AuthProvider>();
    return staffAuthProvider.staffDetails != null ? null : authProvider.accessToken;
  }

  Future<void> _submitData() async {
    setState(() {
      _isLoading = true;
    });

    final staffAuthProvider = context.read<StaffAuthProvider>();
    final authProvider = context.read<AuthProvider>();

    final String cafeUserName = staffAuthProvider.staffDetails?['cafeUserName'] ??
        authProvider.user?.cafeUserName ??
        "cafe123456";

    final String? accessToken = await _resolveAccessToken();

    // Updated to use AppConfig.baseUrl cleanly
    final String urlString = '${AppConfig.baseUrl}/table';
    final url = Uri.parse(urlString);

    final requestBody = {
      "name": _nameController.text.trim(),
      "capacity": int.tryParse(_capacityController.text.trim()) ?? 0,
      "cafeUserName": cafeUserName,
    };

    try {
      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
          if (accessToken != null) 'Authorization': 'Bearer $accessToken',
        },
        body: json.encode(requestBody),
      );

      final decoded = json.decode(response.body);

      if (response.statusCode == 200 || response.statusCode == 201) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(decoded['message'] ?? "Table created successfully")),
          );
          Navigator.pop(context);
        }
      } else {
        String errorMessage = "Failed to create table";
        if (decoded['error'] is Map && decoded['error']['name'] != null) {
          errorMessage = decoded['error']['name'];
        } else if (decoded['message'] != null) {
          errorMessage = decoded['message'];
        }

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(errorMessage)),
          );
        }
      }
    } catch (e) {
      debugPrint("Exception during create table: $e");
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Error: $e")),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text(
          "New Table",
          style: GoogleFonts.poppins(
            color: isDarkMode ? Colors.white : Colors.black87,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: IconThemeData(color: isDarkMode ? Colors.white : Colors.black87),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            CustomTextField(
              controller: _nameController,
              label: "Table Name",
              icon: Icons.table_restaurant,
            ),
            const SizedBox(height: 20),
            CustomTextField(
              controller: _capacityController,
              label: "Seating Capacity",
              icon: Icons.people,
              isNumber: true,
            ),
            const SizedBox(height: 40),
            SizedBox(
              height: 56,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.indigo,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  elevation: 0,
                ),
                onPressed: _isLoading ? null : _submitData,
                child: _isLoading
                    ? Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        color: Colors.white,
                        strokeWidth: 2,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Text(
                      "Creating Table...",
                      style: GoogleFonts.poppins(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                      ),
                    ),
                  ],
                )
                    : Text(
                  "Save Table",
                  style: GoogleFonts.poppins(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}