import 'dart:math';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class SipSnapAnimatedLogo extends StatefulWidget {
  final double fontSize;

  const SipSnapAnimatedLogo({
    super.key,
    this.fontSize = 24, // Made smaller and sleeker by default
  });

  @override
  State<SipSnapAnimatedLogo> createState() => _SipSnapAnimatedLogoState();
}

class _SipSnapAnimatedLogoState extends State<SipSnapAnimatedLogo>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000), // Slightly slower for a graceful, premium pace
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;
    final sipColor = isDarkMode ? Colors.white : const Color(0xFF35261E);
    const snapColor = Color(0xFFE68A36);

    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return Row(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _buildCreativeText("Sip", sipColor, _controller.value, 0.0),
            const SizedBox(width: 2), // Tiny elegant spacing between words
            _buildCreativeText("Snap", snapColor, _controller.value, 0.35),
          ],
        );
      },
    );
  }

  Widget _buildCreativeText(String text, Color color, double progress, double phaseOffset) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(text.length, (index) {
        // Smooth wave offset (reduced height for a professional, subtle bounce)
        final double wave = sin((progress * 2 * pi) + phaseOffset + (index * 0.45)) * 4.5;

        // Subtle scale pulse matching the wave
        final double scale = 1.0 + (sin((progress * 2 * pi) + phaseOffset + (index * 0.45)) * 0.06);

        // Subtle opacity fade for a sophisticated trailing effect
        final double opacity = 0.65 + (0.35 * ((wave.abs() / 4.5).clamp(0.0, 1.0)));

        return Transform.translate(
          offset: Offset(0, wave),
          child: Transform.scale(
            scale: scale,
            child: Opacity(
              opacity: opacity,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 0.5),
                child: Text(
                  text[index],
                  style: GoogleFonts.poppins(
                    fontSize: widget.fontSize,
                    fontWeight: FontWeight.w700,
                    color: color,
                    letterSpacing: -0.5,
                    shadows: [
                      Shadow(
                        color: color.withOpacity(0.15),
                        offset: const Offset(0, 2),
                        blurRadius: 4,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      }),
    );
  }
}