class ImageModel {
  final String publicId;
  final String secureUrl;
  final String optimizedUrl;

  ImageModel({
    required this.publicId,
    required this.secureUrl,
    required this.optimizedUrl,
  });

  factory ImageModel.fromJson(Map<String, dynamic> json) {
    return ImageModel(
      publicId: json['publicId'] ?? '',
      secureUrl: json['secureUrl'] ?? '',
      optimizedUrl: json['optimizedUrl'] ?? '',
    );
  }
}

class UserModel {
  final String id;
  final String name;
  final String email;
  final String role;
  final String status;
  final String address;
  final String phone;
  final String? gender;
  final String? dob;
  final ImageModel image;
  final String cafeName;
  final String cafeUserName;

  UserModel({
    required this.id,
    required this.name,
    required this.email,
    required this.role,
    required this.status,
    required this.address,
    required this.phone,
    this.gender,
    this.dob,
    required this.image,
    required this.cafeName,
    required this.cafeUserName,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['_id'] ?? '',
      name: json['name'] ?? '',
      email: json['email'] ?? '',
      role: json['role'] ?? '',
      status: json['status'] ?? '',
      address: json['address'] ?? '',
      phone: json['phone'] ?? '',
      gender: json['gender'],
      dob: json['dob'],
      image: ImageModel.fromJson(json['image'] ?? {}),
      cafeName: json['cafeName'] ?? '',
      cafeUserName: json['cafeUserName'] ?? '',
    );
  }

  String? operator [](String other) {}
}