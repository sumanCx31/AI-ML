package com.example.egcafe

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
